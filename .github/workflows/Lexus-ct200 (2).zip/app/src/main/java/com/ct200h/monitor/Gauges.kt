package com.ct200h.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale

/** Ring gauge for state of charge. Toyota keeps SOC roughly between 40 and 80 %. */
class SocRingView(ctx: Context) : View(ctx) {
    var soc: Double? = null
        set(v) { field = v; invalidate() }

    private val d = ctx.resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 12 * d; color = C.CARD2; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 12 * d; strokeCap = Paint.Cap.ROUND }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.TEXT; textSize = 34 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 11 * d; textAlign = Paint.Align.CENTER }
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) {
        val s = (150 * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val pad = 10 * d
        r.set(pad, pad, width - pad, height - pad)
        c.drawArc(r, 135f, 270f, false, track)
        val s = soc
        if (s != null) {
            arc.color = when { s < 45 -> C.ORANGE; s > 78 -> C.BLUE; else -> C.GREEN }
            c.drawArc(r, 135f, (270f * (s / 100.0).coerceIn(0.0, 1.0)).toFloat(), false, arc)
        }
        val cy = height / 2f
        c.drawText(s?.let { String.format(Locale.US, "%.0f%%", it) } ?: "—", width / 2f, cy + 10 * d, big)
        c.drawText("ЗАРЯД ВВБ", width / 2f, cy + 30 * d, cap)
    }
}

/** Horizontal bar centred at 0 A: right/orange = battery giving power, left/green = charging (regen). */
class CurrentBarView(ctx: Context) : View(ctx) {
    var amps: Double? = null
        set(v) { field = v; invalidate() }

    private val d = ctx.resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.CARD2 }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint().apply { color = C.MUTED; strokeWidth = 2 * d }
    private val cap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 10 * d }
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (40 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val top = 4 * d
        val bh = 14 * d
        r.set(0f, top, width.toFloat(), top + bh)
        c.drawRoundRect(r, bh / 2, bh / 2, track)
        val mid = width / 2f
        val a = amps ?: 0.0
        val frac = (a / 150.0).coerceIn(-1.0, 1.0).toFloat()
        fill.color = if (a < 0) C.GREEN else C.ORANGE
        if (frac >= 0) r.set(mid, top, mid + frac * mid, top + bh) else r.set(mid + frac * mid, top, mid, top + bh)
        c.drawRoundRect(r, bh / 2, bh / 2, fill)
        c.drawLine(mid, top - 2 * d, mid, top + bh + 2 * d, tick)
        cap.textAlign = Paint.Align.LEFT
        c.drawText("◀ зарядка", 0f, top + bh + 16 * d, cap)
        cap.textAlign = Paint.Align.RIGHT
        c.drawText("расход ▶", width.toFloat(), top + bh + 16 * d, cap)
    }
}
