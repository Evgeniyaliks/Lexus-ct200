package com.ct200h.monitor

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.rgb(13, 17, 23)
    val CARD = Color.rgb(22, 27, 34)
    val CARD2 = Color.rgb(30, 36, 45)
    val LINE = Color.rgb(48, 54, 61)
    val TEXT = Color.rgb(230, 237, 243)
    val MUTED = Color.rgb(139, 148, 158)
    val GREEN = Color.rgb(63, 185, 80)
    val ORANGE = Color.rgb(240, 136, 62)
    val RED = Color.rgb(248, 81, 73)
    val YELLOW = Color.rgb(210, 153, 34)
    val BLUE = Color.rgb(88, 166, 255)

    fun level(l: Int) = when (l) { 0 -> GREEN; 1 -> YELLOW; else -> RED }
}

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

fun Context.text(size: Float, color: Int = C.TEXT, bold: Boolean = false, mono: Boolean = false): TextView =
    TextView(this).apply {
        textSize = size
        setTextColor(color)
        typeface = when {
            mono && bold -> Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            mono -> Typeface.MONOSPACE
            bold -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            else -> Typeface.create("sans-serif", Typeface.NORMAL)
        }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(C.CARD, dp(16f).toFloat())
    setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
}

fun Context.sectionTitle(t: String): TextView = text(12f, C.MUTED, bold = true).apply {
    text = t.uppercase()
    letterSpacing = 0.08f
    setPadding(0, 0, 0, dp(8f))
}

fun LinearLayout.addSpaced(v: View, topDp: Float = 12f) {
    val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    lp.topMargin = context.dp(topDp)
    addView(v, lp)
}

/** A small tile: caption on top, big value, optional sub-line. */
class Tile(ctx: Context) : LinearLayout(ctx) {
    val caption = ctx.text(11f, C.MUTED, bold = true)
    val value = ctx.text(22f, C.TEXT, bold = true)
    val sub = ctx.text(11f, C.MUTED)

    init {
        orientation = VERTICAL
        background = rounded(C.CARD, ctx.dp(14f).toFloat())
        setPadding(ctx.dp(14f), ctx.dp(12f), ctx.dp(14f), ctx.dp(12f))
        addView(caption); addView(value); addView(sub)
    }

    fun set(cap: String, v: String, s: String = "", color: Int = C.TEXT) {
        caption.text = cap.uppercase(); value.text = v; value.setTextColor(color); sub.text = s
        sub.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
    }
}

/** Row of equal-width tiles. */
fun Context.tileRow(vararg tiles: Tile): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    tiles.forEachIndexed { i, t ->
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        if (i > 0) lp.leftMargin = dp(10f)
        addView(t, lp)
    }
}

/** Pill-shaped status label. */
fun Context.chip(): TextView = text(13f, C.TEXT, bold = true).apply {
    gravity = Gravity.CENTER_VERTICAL
    setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
}

fun TextView.setChip(label: String, color: Int) {
    text = "●  $label"
    setTextColor(color)
    background = rounded(Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)), context.dp(20f).toFloat())
}
