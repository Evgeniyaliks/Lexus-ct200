package com.ct200h.monitor

import java.util.concurrent.ConcurrentHashMap

/**
 * Extra (non-battery) data for Gen3 Prius / CT200h, polled one request per loop so the battery log stays fast.
 * Formulas from OBDb/Toyota-Prius (signals valid for 2010–2015). A PID that never answers is marked unsupported.
 */
class Pid(val hdr: String, val cmd: String, val minLen: Int, val decode: (ByteArray, MutableMap<String, Double>) -> Unit) {
    var fails = 0
    var ok = false
    val unsupported: Boolean get() = !ok && fails >= 3
}

object Extras {
    /** Inverter coolant this hot usually means the inverter pump is weak (common Gen3 failure, P0A93). */
    const val INV_COOL_WARN = 65.0
    val values = ConcurrentHashMap<String, Double>()
    val unsupportedKeys = ConcurrentHashMap.newKeySet<String>()

    private fun c(b: Int) = b - 40.0

    /** Engine block 21 01 — also used for coolant/rpm/MAF in the fast loop. */
    val engine = Pid("7E0", "2101", 15) { b, m ->
        m["load"] = b.u8(0) * 100.0 / 255
        m["maf"] = b.u16(3) / 100.0
        m["map"] = b.u8(5).toDouble()
        m["iat"] = c(b.u8(6))
        m["ect"] = c(b.u8(8))
        m["rpm"] = b.u16(9) / 4.0
        m["runtime"] = b.u16(12).toDouble()
        m["tps"] = b.u8(14) * 100.0 / 255
        if (b.size >= 25) m["ecu12v"] = b.u16(23) / 1000.0
    }

    val slow: List<Pid> = listOf(
        Pid("7E0", "2103", 5) { b, m ->
            m["stft"] = b.u8(2) * 200.0 / 256 - 100
            m["ltft"] = b.u8(3) * 200.0 / 256 - 100
            m["ign"] = b.u8(4) / 2.0 - 64
        },
        Pid("7E0", "2105", 6) { b, m -> m["cat1"] = b.u16(2) / 10.0 - 40; m["cat2"] = b.u16(4) / 10.0 - 40 },
        Pid("7E0", "2128", 3) { b, m -> m["odoKm"] = ((b.u8(0) shl 16) or (b.u8(1) shl 8) or b.u8(2)).toDouble() },
        Pid("7E0", "2145", 8) { b, m ->
            for (i in 1..4) m["mis$i"] = b.u8(2 + i).toDouble()
            m["misAll"] = b.u8(7).toDouble()
        },
        Pid("7E0", "2151", 10) { b, m -> m["eot"] = c(b.u8(9)) },
        Pid("7E2", "2161", 1) { b, m -> m["mg1"] = c(b.u8(0)) },
        Pid("7E2", "2162", 1) { b, m -> m["mg2"] = c(b.u8(0)) },
        Pid("7E2", "2170", 1) { b, m -> m["inv1"] = c(b.u8(0)) },
        Pid("7E2", "2171", 1) { b, m -> m["inv2"] = c(b.u8(0)) },
        Pid("7E2", "2174", 2) { b, m -> m["boostU"] = c(b.u8(0)); m["boostL"] = c(b.u8(1)) },
        Pid("7E2", "2175", 4) { b, m -> m["invPump"] = b.u16(1).toDouble(); m["invCool"] = c(b.u8(3)) },
        Pid("7E2", "217D", 3) { b, m -> m["acW"] = b.u8(2) * 50.0 },
        Pid("7E2", "218E", 1) { b, m -> m["hvFan"] = b.u8(0) / 2.0 },
        Pid("7E2", "2192", 15) { b, m ->
            m["cntLow"] = b.u16(7).toDouble(); m["cntDcInh"] = b.u16(9).toDouble()
            m["cntHigh"] = b.u16(11).toDouble(); m["cntHot"] = b.u16(13).toDouble()
        },
        Pid("750", "2130", 4) { b, m ->
            val names = listOf("tpFL", "tpFR", "tpRL", "tpRR")
            for (i in 0 until 4) { val bar = b.u8(i) / 58.0 - 0.5; if (bar > 0 && bar < 3.89) m[names[i]] = bar }
        },
        Pid("750", "2116", 4) { b, m ->
            val names = listOf("ttFL", "ttFR", "ttRL", "ttRR")
            for (i in 0 until 4) if (b.u8(i) != 0) m[names[i]] = c(b.u8(i))
        },
        Pid("7C4", "2121", 1) { b, m -> m["cabin"] = b.u8(0) * 63.75 / 255 - 6.5 },
        Pid("7C4", "2122", 1) { b, m -> m["ambient"] = b.u8(0) * 89.25 / 255 - 23.3 },
        Pid("7C4", "2149", 2) { b, m -> m["compRpm"] = b.u16(0).toDouble() },
        Pid("7C0", "2129", 1) { b, m -> m["fuelGal"] = b.u8(0) * 500.0 / 3785 },
    )

    /** Which value keys each PID provides, to show "не поддерживается" in the UI. */
    private val keysOf: Map<String, List<String>> = mapOf(
        "2103" to listOf("stft", "ltft", "ign"), "2105" to listOf("cat1", "cat2"), "2128" to listOf("odoKm"),
        "2145" to listOf("mis1", "mis2", "mis3", "mis4", "misAll"), "2151" to listOf("eot"),
        "2161" to listOf("mg1"), "2162" to listOf("mg2"), "2170" to listOf("inv1"), "2171" to listOf("inv2"),
        "2174" to listOf("boostU", "boostL"), "2175" to listOf("invPump", "invCool"), "217D" to listOf("acW"),
        "218E" to listOf("hvFan"), "2192" to listOf("cntLow", "cntDcInh", "cntHigh", "cntHot"),
        "2130" to listOf("tpFL", "tpFR", "tpRL", "tpRR"), "2116" to listOf("ttFL", "ttFR", "ttRL", "ttRR"),
        "2121" to listOf("cabin"), "2122" to listOf("ambient"), "2149" to listOf("compRpm"), "2129" to listOf("fuelGal"),
    )

    private var idx = 0

    fun reset() {
        idx = 0
        values.clear()
        for (p in slow + engine) { p.fails = 0; p.ok = false }
        unsupportedKeys.clear()
    }

    fun run(elm: Elm, p: Pid): Boolean {
        val b = elm.request(p.hdr, p.cmd)
        if (b == null || b.size < p.minLen) {
            p.fails++
            if (p.unsupported) keysOf[p.cmd]?.let { unsupportedKeys.addAll(it) }
            return false
        }
        val m = HashMap<String, Double>()
        try { p.decode(b, m) } catch (_: Exception) { p.fails++; return false }
        p.ok = true; p.fails = 0
        values.putAll(m)
        return true
    }

    /** Polls the next supported slow PID. */
    fun pollOne(elm: Elm) {
        for (k in slow.indices) {
            val p = slow[(idx + k) % slow.size]
            if (p.unsupported) continue
            idx = (idx + k + 1) % slow.size
            run(elm, p)
            return
        }
    }

    fun get(key: String): Double? = values[key]
}

/** Fuel use estimate from MAF (stoichiometric, gasoline 745 g/L). */
object Fuel {
    fun galPerHour(mafGs: Double): Double = mafGs * 3600.0 / 14.7 / 745.0 / 3.78541
    fun instantMpg(mafGs: Double?, mph: Double?): Double? {
        if (mafGs == null || mph == null || mph < 2) return null
        val gph = galPerHour(mafGs)
        return if (gph < 0.02) 99.0 else minOf(99.0, mph / gph)
    }
}

/**
 * Body ECU settings with commands published on PriusChat (header 7C0, read 21xx / write 3Bxx).
 * Reverse beep: byte AC, bit 0x40 set = beep off. Seat-belt chime: byte A7, writing 00 turns it off;
 * the "on" value differs per car, so the original byte is backed up and restored as-is.
 */
object Custom {
    const val HDR = "7C0"
    const val REVERSE = "AC"
    const val SEATBELT = "A7"

    fun read(elm: Elm, id: String): Int? = elm.request(HDR, "21$id")?.takeIf { it.isNotEmpty() }?.u8(0)

    /** Writes and reads back. Returns the value now in the ECU, or null if it didn't answer. */
    fun write(elm: Elm, id: String, value: Int): Pair<Int?, String> {
        val raw = elm.requestRaw(HDR, String.format("3B%s%02X", id, value), 5000).replace('\n', ' ')
        Thread.sleep(300)
        return Pair(read(elm, id), raw)
    }
}
