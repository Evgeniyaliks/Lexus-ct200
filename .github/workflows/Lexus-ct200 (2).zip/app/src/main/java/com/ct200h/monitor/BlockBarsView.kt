package com.ct200h.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import java.util.Locale

/**
 * 14 blocks shown as 7 pairs (the ECU reports them in pairs).
 * Each bar is the block's deviation from the pack average; red = lagging ≥0.33V, yellow = current weakest.
 */
class BlockBarsView(ctx: Context) : View(ctx) {
    var blocks: DoubleArray? = null
        set(v) { field = v; invalidate() }

    private val d = ctx.resources.displayMetrics.density
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.CARD2 }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 11 * d; textAlign = Paint.Align.CENTER }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 8.5f * d; textAlign = Paint.Align.CENTER }
    private val axis = Paint().apply { color = C.LINE; strokeWidth = 1 * d }
    private val pairBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.CARD2; alpha = 90 }
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (170 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val b = blocks
        if (b == null) {
            c.drawText("ждём данные…", width / 2f, height / 2f, label); return
        }
        val avg = b.average()
        val scale = 0.4                                   // ±0.4 V full height
        val top = 6 * d
        val bottom = height - 34 * d
        val mid = (top + bottom) / 2
        val half = (bottom - top) / 2
        val pairW = width / 7f
        val minIdx = b.indices.minBy { b[it] }

        for (p in 0 until 7) {
            r.set(p * pairW + 3 * d, top - 2 * d, (p + 1) * pairW - 3 * d, height - 2 * d)
            c.drawRoundRect(r, 10 * d, 10 * d, pairBg)
        }
        c.drawLine(0f, mid, width.toFloat(), mid, axis)

        for (i in 0 until 14) {
            val p = i / 2
            val inPair = i % 2
            val slotW = (pairW - 12 * d) / 2
            val x0 = p * pairW + 6 * d + inPair * slotW + slotW * 0.2f
            val x1 = x0 + slotW * 0.6f
            r.set(x0, top, x1, bottom)
            c.drawRoundRect(r, 4 * d, 4 * d, track)
            val dev = b[i] - avg
            val h = (dev / scale).coerceIn(-1.0, 1.0).toFloat() * half
            bar.color = when {
                -dev >= 0.33 -> C.RED
                i == minIdx -> C.YELLOW
                dev < 0 -> C.ORANGE
                else -> C.GREEN
            }
            if (h >= 0) r.set(x0, mid - h, x1, mid) else r.set(x0, mid, x1, mid - h)
            if (Math.abs(h) < 2 * d) r.set(x0, mid - 1 * d, x1, mid + 1 * d)
            c.drawRoundRect(r, 4 * d, 4 * d, bar)
            val cx = (x0 + x1) / 2
            c.drawText("${i + 1}", cx, height - 18 * d, label)
            c.drawText(String.format(Locale.US, "%.2f", b[i]), cx, height - 6 * d, small)
        }
    }
}
