package com.ct200h.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import java.util.Locale

class Series(val name: String, val color: Int, val values: List<Double?>)

/** Simple multi-line chart over trips (x = trip index). Optional dashed threshold line. */
class LineChartView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var series: List<Series> = emptyList()
        set(v) { field = v; invalidate() }
    var threshold: Double? = null
    var thresholdLabel = ""
    var unit = ""
    var xLabels: List<String> = emptyList()
    var fixedMin: Double? = null
    var fixedMax: Double? = null

    private val grid = Paint().apply { color = C.LINE; strokeWidth = 1 * d }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d; strokeJoin = Paint.Join.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thr = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = C.RED; pathEffect = DashPathEffect(floatArrayOf(8 * d, 6 * d), 0f)
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 10 * d }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (180 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val all = series.flatMap { s -> s.values.filterNotNull() } + listOfNotNull(threshold)
        val n = series.maxOfOrNull { it.values.size } ?: 0
        if (all.isEmpty() || n == 0) {
            txt.textAlign = Paint.Align.CENTER
            c.drawText("пока мало поездок", width / 2f, height / 2f, txt); return
        }
        var lo = fixedMin ?: all.min()
        var hi = fixedMax ?: all.max()
        if (hi - lo < 1e-6) { hi += 0.5; lo -= 0.5 }
        val padL = 40 * d; val padR = 8 * d; val padT = 22 * d; val padB = 20 * d
        val w = width - padL - padR; val h = height - padT - padB
        fun x(i: Int) = padL + if (n <= 1) w / 2 else w * i / (n - 1).toFloat()
        fun y(v: Double) = padT + h - ((v - lo) / (hi - lo) * h).toFloat()

        txt.textAlign = Paint.Align.RIGHT
        for (k in 0..3) {
            val v = lo + (hi - lo) * k / 3
            val yy = y(v)
            c.drawLine(padL, yy, width - padR, yy, grid)
            c.drawText(String.format(Locale.US, if (hi - lo < 3) "%.2f" else "%.0f", v), padL - 4 * d, yy + 3 * d, txt)
        }
        threshold?.let { t ->
            val p = Path(); p.moveTo(padL, y(t)); p.lineTo(width - padR, y(t)); c.drawPath(p, thr)
            txt.textAlign = Paint.Align.RIGHT; txt.color = C.RED
            c.drawText(thresholdLabel, width - padR, y(t) - 4 * d, txt); txt.color = C.MUTED
        }
        for (s in series) {
            line.color = s.color; dot.color = s.color
            val p = Path(); var started = false
            s.values.forEachIndexed { i, v ->
                if (v == null) return@forEachIndexed
                if (!started) { p.moveTo(x(i), y(v)); started = true } else p.lineTo(x(i), y(v))
                c.drawCircle(x(i), y(v), 3 * d, dot)
            }
            c.drawPath(p, line)
        }
        // legend
        txt.textAlign = Paint.Align.LEFT
        var lx = padL
        for (s in series) {
            dot.color = s.color
            c.drawCircle(lx + 4 * d, 9 * d, 4 * d, dot)
            c.drawText(s.name, lx + 12 * d, 13 * d, txt)
            lx += txt.measureText(s.name) + 28 * d
        }
        if (xLabels.isNotEmpty()) {
            txt.textAlign = Paint.Align.LEFT; c.drawText(xLabels.first(), padL, height - 4 * d, txt)
            txt.textAlign = Paint.Align.RIGHT; c.drawText(xLabels.last(), width - padR, height - 4 * d, txt)
        }
    }
}

/** Rows = 14 blocks, columns = trips. Colour = block's average deviation from the pack in that trip. */
class HeatmapView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    /** columns[trip][block] in volts */
    var columns: List<DoubleArray> = emptyList()
        set(v) { field = v; requestLayout(); invalidate() }
    var xLabels: List<String> = emptyList()

    private val cell = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.MUTED; textSize = 10 * d }
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (14 * 16 * d + 40 * d).toInt())
    }

    private fun colorFor(v: Double): Int {
        val t = (Math.abs(v) / 0.10).coerceIn(0.0, 1.0)
        val base = if (v < 0) C.RED else C.GREEN
        val a = (40 + 215 * t).toInt()
        return Color.argb(a, Color.red(base), Color.green(base), Color.blue(base))
    }

    override fun onDraw(c: Canvas) {
        val padL = 30 * d; val padT = 4 * d
        val rowH = 16 * d
        if (columns.isEmpty()) {
            txt.textAlign = Paint.Align.CENTER
            c.drawText("пока мало поездок", width / 2f, height / 2f, txt); return
        }
        val colW = (width - padL) / columns.size.toFloat()
        txt.textAlign = Paint.Align.RIGHT
        for (b in 0 until 14) {
            val y0 = padT + b * rowH
            c.drawText("№${b + 1}", padL - 6 * d, y0 + rowH * 0.72f, txt)
            columns.forEachIndexed { i, col ->
                cell.color = colorFor(col[b])
                r.set(padL + i * colW + 1 * d, y0 + 1 * d, padL + (i + 1) * colW - 1 * d, y0 + rowH - 1 * d)
                c.drawRoundRect(r, 3 * d, 3 * d, cell)
            }
        }
        val yb = padT + 14 * rowH + 14 * d
        if (xLabels.isNotEmpty()) {
            txt.textAlign = Paint.Align.LEFT; c.drawText(xLabels.first(), padL, yb, txt)
            txt.textAlign = Paint.Align.RIGHT; c.drawText(xLabels.last(), width.toFloat(), yb, txt)
        }
        txt.textAlign = Paint.Align.LEFT
        cell.color = colorFor(-0.1); r.set(padL, yb + 8 * d, padL + 12 * d, yb + 20 * d); c.drawRoundRect(r, 3 * d, 3 * d, cell)
        c.drawText("отстаёт", padL + 16 * d, yb + 18 * d, txt)
        val x2 = padL + 90 * d
        cell.color = colorFor(0.1); r.set(x2, yb + 8 * d, x2 + 12 * d, yb + 20 * d); c.drawRoundRect(r, 3 * d, 3 * d, cell)
        c.drawText("сильнее среднего", x2 + 16 * d, yb + 18 * d, txt)
    }
}
