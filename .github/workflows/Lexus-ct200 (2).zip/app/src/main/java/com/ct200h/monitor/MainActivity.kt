package com.ct200h.monitor

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val listener: () -> Unit = { if (tab == 0) renderNow() else if (tab == 1) renderCar() }
    private var tab = 0
    private lateinit var content: FrameLayout
    private lateinit var startBtn: TextView
    private lateinit var headerSub: TextView
    private val tabViews = mutableListOf<TextView>()
    private val pages = arrayOfNulls<View>(5)

    // "Now" page widgets
    private lateinit var statusChip: TextView
    private lateinit var ring: SocRingView
    private lateinit var ampsText: TextView
    private lateinit var ampsSub: TextView
    private lateinit var ampBar: CurrentBarView
    private lateinit var spreadText: TextView
    private lateinit var bars: BlockBarsView
    private lateinit var barsCaption: TextView
    private lateinit var tTemp: Tile
    private lateinit var t12v: Tile
    private lateinit var tEngine: Tile
    private lateinit var tTrip: Tile
    private lateinit var codesText: TextView
    private lateinit var eventsText: TextView

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.CARD

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(14f), dp(14f), dp(10f))
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text(20f, C.TEXT, bold = true).apply { text = "Lexus CT200h" })
        headerSub = text(12f, C.MUTED)
        titles.addView(headerSub)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        startBtn = text(15f, Color.BLACK, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(22f), dp(10f), dp(22f), dp(10f))
            setOnClickListener { toggle() }
        }
        header.addView(startBtn)
        root.addView(header)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        // Bottom tabs
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(C.CARD) }
        listOf("◉\nВВБ", "◈\nМашина", "☰\nПоездки", "↗\nТренды", "⚙\nСервис").forEachIndexed { i, t ->
            val tv = text(12f, C.MUTED, bold = true).apply {
                text = t; gravity = Gravity.CENTER; setPadding(0, dp(8f), 0, dp(8f))
                setOnClickListener { showTab(i) }
            }
            tabViews += tv
            nav.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)

        requestPerms()
        showTab(intent?.getIntExtra("tab", 0) ?: 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { if (it.hasExtra("tab")) showTab(it.getIntExtra("tab", 0)) }
    }

    override fun onResume() {
        super.onResume()
        Live.addListener(listener)
        showTab(tab)
    }

    override fun onPause() {
        Live.removeListener(listener)
        super.onPause()
    }

    private fun prefs() = getSharedPreferences(MonitorService.PREFS, MODE_PRIVATE)

    private fun showTab(i: Int) {
        tab = i
        tabViews.forEachIndexed { k, tv -> tv.setTextColor(if (k == i) C.GREEN else C.MUTED) }
        // Trips/trends/service pages are rebuilt each time so they show fresh data
        val page: View = when (i) {
            0 -> pages[0] ?: buildNow().also { pages[0] = it }
            1 -> pages[1] ?: buildCar().also { pages[1] = it }
            2 -> buildTrips()
            3 -> buildTrends()
            else -> buildService()
        }
        content.removeAllViews()
        content.addView(page)
        renderHeader()
        if (i == 0) renderNow()
        if (i == 1) renderCar()
    }

    private fun scrollPage(): Pair<ScrollView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14f), dp(4f), dp(14f), dp(20f))
        }
        val sv = ScrollView(this).apply { addView(col); isFillViewport = true }
        return Pair(sv, col)
    }

    private fun renderHeader() {
        startBtn.text = if (Live.running) "Стоп" else "Старт"
        startBtn.background = rounded(if (Live.running) C.RED else C.GREEN, dp(22f).toFloat())
        val name = prefs().getString("name", null)
        headerSub.text = when {
            name == null -> "Адаптер не выбран"
            else -> "${Live.status} · $name"
        }
    }

    // ================= NOW =================

    private fun buildNow(): View {
        val (sv, col) = scrollPage()
        statusChip = chip()
        col.addSpaced(LinearLayout(this).apply { addView(statusChip) }, 4f)

        // Hero: SOC ring + current
        val hero = card().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        ring = SocRingView(this)
        hero.addView(ring)
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14f), 0, 0, 0) }
        right.addView(text(11f, C.MUTED, bold = true).apply { text = "ТОК ВВБ" })
        ampsText = text(30f, C.TEXT, bold = true)
        ampsSub = text(12f, C.MUTED)
        right.addView(ampsText); right.addView(ampsSub)
        ampBar = CurrentBarView(this)
        right.addSpaced(ampBar, 8f)
        spreadText = text(13f, C.TEXT, bold = true)
        right.addSpaced(spreadText, 6f)
        hero.addView(right, LinearLayout.LayoutParams(0, -2, 1f))
        col.addSpaced(hero)

        // Blocks
        val bc = card()
        bc.addView(sectionTitle("Блоки ВВБ · отклонение от среднего"))
        bars = BlockBarsView(this)
        bc.addView(bars)
        barsCaption = text(13f, C.MUTED)
        bc.addSpaced(barsCaption, 8f)
        col.addSpaced(bc)

        tTemp = Tile(this); t12v = Tile(this); tEngine = Tile(this); tTrip = Tile(this)
        col.addSpaced(tileRow(tTemp, t12v))
        col.addSpaced(tileRow(tEngine, tTrip), 10f)

        val cc = card()
        cc.addView(sectionTitle("Коды ошибок"))
        codesText = text(14f, C.TEXT)
        cc.addView(codesText)
        col.addSpaced(cc)

        val ec = card()
        ec.addView(sectionTitle("События"))
        eventsText = text(12f, C.MUTED, mono = true)
        ec.addView(eventsText)
        col.addSpaced(ec)
        return sv
    }

    private fun f1(v: Double?, fmt: String) = v?.let { String.format(Locale.US, fmt, it) } ?: "—"

    private fun renderNow() {
        renderHeader()
        if (pages[0] == null) return
        val s = Live.snap
        val tripNow = Live.trip
        val active = Live.dtcs
        val perm = Live.permanentDtcs

        when {
            !Live.running -> statusChip.setChip("Запись выключена — нажми «Старт»", C.MUTED)
            !Live.recording -> statusChip.setChip("Жду READY…", C.BLUE)
            active.isNotEmpty() -> statusChip.setChip("Ошибка: ${active.joinToString(", ")}", C.RED)
            s != null && s.lowDev >= 0.33 -> statusChip.setChip("Блок №${s.minBlock} отстаёт", C.RED)
            s != null && s.spread >= 0.5 -> statusChip.setChip(String.format(Locale.US, "Разброс %.2f V", s.spread), C.YELLOW)
            else -> statusChip.setChip("Батарея в норме", C.GREEN)
        }

        ring.soc = s?.soc
        val a = s?.current
        ampsText.text = if (a == null) "—" else String.format(Locale.US, "%+.0f A", a)
        ampsText.setTextColor(if (a != null && a < -1) C.GREEN else if (a != null && a > 1) C.ORANGE else C.TEXT)
        ampsSub.text = when {
            a == null -> ""
            a < -1 -> "батарея заряжается"
            a > 1 -> "батарея отдаёт энергию"
            else -> "без нагрузки"
        }
        ampBar.amps = a
        spreadText.text = if (s == null) "" else String.format(Locale.US, "Разброс блоков  %.2f V", s.spread)
        spreadText.setTextColor(if (s != null && s.spread >= 0.5) C.YELLOW else C.TEXT)

        bars.blocks = s?.blocks
        barsCaption.text = if (s == null) "" else buildString {
            append(String.format(Locale.US, "Слабее всех сейчас №%d (−%.2f V)", s.minBlock, s.lowDev))
            s.ecuWeakest?.let { append("\nЭБУ считает слабейшим №$it") }
            tripNow?.weakestTop()?.takeIf { it.isNotEmpty() }?.let { append("\nЗа поездку чаще отставали: ${it.joinToString(", ") { n -> "№$n" }}") }
        }

        val t = s?.tempsF
        if (t != null) {
            val mx = maxOf(t[1], t[2], t[3]); val mn = minOf(t[1], t[2], t[3])
            tTemp.set("Темп. ВВБ", String.format(Locale.US, "%.0f°F", mx),
                String.format(Locale.US, "%.0f–%.0f°F · воздух %.0f°F", mn, mx, t[0]),
                if (mx >= 113) C.RED else if (mx >= 104) C.YELLOW else C.TEXT)
        } else tTemp.set("Темп. ВВБ", "—")

        val rest = Live.restingAux
        val restLine = rest?.let { String.format(Locale.US, "в покое %.2f V", it) } ?: "в покое: нет замера"
        t12v.set("12V", f1(s?.aux, "%.2f V"), restLine,
            if (rest != null && rest < 12.2) C.YELLOW else C.TEXT)

        val cool = s?.coolantC
        val rpm = s?.rpm
        tEngine.set("Двигатель", if (cool == null) "—" else String.format(Locale.US, "%.0f°C", cool),
            when { rpm == null -> ""; rpm < 100 -> "заглушен · едем на электричестве"; else -> "$rpm об/мин" },
            if (cool != null && cool >= 105) C.RED else if (cool != null && cool >= 100) C.YELLOW else C.TEXT)

        if (tripNow != null && tripNow.rows > 0) {
            tTrip.set("Поездка", String.format(Locale.US, "%.0f мин", tripNow.durationMin),
                String.format(Locale.US, "%.1f mi · EV %.0f%% · %s mph", tripNow.distanceMi, tripNow.evShare, f1(s?.speedMph, "%.0f")))
        } else tTrip.set("Поездка", "—", "начнётся с READY")

        codesText.text = buildString {
            append(if (active.isEmpty()) "Активных ошибок нет" else "Активные: ${active.joinToString(", ")}")
            if (perm.isNotEmpty()) {
                append("\nПостоянные (история): ${perm.joinToString(", ")}")
                append("\nЭто след прошлой ошибки. Сканером не стирается — ЭБУ уберёт сам после успешной самопроверки.")
            }
        }
        codesText.setTextColor(if (active.isNotEmpty()) C.RED else C.TEXT)
        eventsText.text = Live.events.take(10).joinToString("\n").ifEmpty { "пока ничего" }
    }


    // ================= CAR =================

    private class CarTile(val tile: Tile, val render: () -> Unit)
    private val carTiles = mutableListOf<CarTile>()
    private lateinit var carNote: TextView
    private lateinit var customText: TextView

    private fun x(k: String) = Extras.get(k)
    private fun na(vararg keys: String) = keys.all { it in Extras.unsupportedKeys }
    private fun fx(k: String, fmt: String): String = x(k)?.let { String.format(Locale.US, fmt, it) } ?: if (na(k)) "н/д" else "—"

    private fun carSection(col: LinearLayout, title: String, vararg tiles: Pair<Tile, () -> Unit>) {
        col.addSpaced(sectionTitle(title).apply { setPadding(dp(4f), 0, 0, 0) }, 16f)
        tiles.toList().chunked(2).forEachIndexed { i, row ->
            val ts = row.map { it.first }.toMutableList()
            if (ts.size == 1) ts += Tile(this).apply { visibility = View.INVISIBLE }
            col.addSpaced(tileRow(*ts.toTypedArray()), if (i == 0) 0f else 10f)
            row.forEach { carTiles += CarTile(it.first, it.second) }
        }
    }

    private fun tile(f: Tile.() -> Unit): Pair<Tile, () -> Unit> { val t = Tile(this); return Pair(t) { t.f() } }

    private fun temp(t: Tile, cap: String, k1: String, k2: String?, warn: Double, hot: Double, sub: String) {
        val v = listOfNotNull(x(k1), k2?.let { x(it) }).maxOrNull()
        val txt = if (k2 == null) fx(k1, "%.0f°C") else if (x(k1) == null && x(k2) == null) fx(k1, "%.0f") else
            String.format(Locale.US, "%s / %s", fx(k1, "%.0f°"), fx(k2, "%.0f°"))
        t.set(cap, txt, sub, when { v == null -> C.TEXT; v >= hot -> C.RED; v >= warn -> C.YELLOW; else -> C.TEXT })
    }

    private fun buildCar(): View {
        val (sv, col) = scrollPage()
        carTiles.clear()
        carNote = text(12f, C.MUTED)
        col.addSpaced(card().apply { addView(carNote) }, 4f)

        carSection(col, "Гибридная система",
            tile { temp(this, "Моторы MG1/MG2", "mg1", "mg2", 90.0, 120.0, "°C · норма до ~90") },
            tile { temp(this, "Инверторы", "inv1", "inv2", 70.0, 85.0, "°C · силовые модули") },
            tile {
                val c = x("invCool"); val p = x("invPump")
                set("ОЖ инвертора", fx("invCool", "%.0f°C"),
                    if (p != null) String.format(Locale.US, "помпа %.0f об/мин", p) else "помпа: —",
                    when { c == null -> C.TEXT; c >= Extras.INV_COOL_WARN -> C.RED; c >= 55 -> C.YELLOW; else -> C.TEXT })
            },
            tile { temp(this, "Повыш. преобр.", "boostU", "boostL", 70.0, 85.0, "°C · boost converter") },
            tile { set("Вентилятор ВВБ", fx("hvFan", "%.0f%%"), "охлаждение батареи") },
            tile { set("Кондиционер", fx("acW", "%.0f W"), x("compRpm")?.let { String.format(Locale.US, "компрессор %.0f об/мин", it) } ?: "мощность компрессора") },
        )

        carSection(col, "Двигатель",
            tile {
                val c = Live.snap?.coolantC
                set("ОЖ / масло", (c?.let { String.format(Locale.US, "%.0f°", it) } ?: "—") + " / " + fx("eot", "%.0f°"),
                    "°C", if (c != null && c >= 105) C.RED else C.TEXT)
            },
            tile {
                val r = Live.snap?.rpm
                set("Обороты", r?.toString() ?: "—", if (r != null && r < 100) "заглушен" else "нагрузка " + fx("load", "%.0f%%"))
            },
            tile {
                val lt = x("ltft")
                set("Топл. коррекции", fx("ltft", "%+.0f%%"), "долгая · короткая " + fx("stft", "%+.0f%%"),
                    if (lt != null && Math.abs(lt) >= 15) C.RED else if (lt != null && Math.abs(lt) >= 10) C.YELLOW else C.TEXT)
            },
            tile { set("Катализатор", fx("cat1", "%.0f°C"), "датчик 1 · УОЗ " + fx("ign", "%.0f°")) },
            tile {
                val m = (1..4).mapNotNull { x("mis$it") }
                set("Пропуски", if (m.isEmpty()) fx("mis1", "%.0f") else m.joinToString(" ") { it.toInt().toString() },
                    "цил. 1–4 · всего " + fx("misAll", "%.0f"), if (m.any { it > 0 }) C.YELLOW else C.TEXT)
            },
            tile { set("Воздух (MAF)", fx("maf", "%.1f г/с"), "впуск " + fx("iat", "%.0f°C")) },
        )

        carSection(col, "Расход и пробег",
            tile {
                val kmh = Live.snap?.speedMph?.let { it * 1.609344 }
                val maf = x("maf")
                val v = if (kmh != null && maf != null && kmh > 5) Fuel.galPerHour(maf) * 3.78541 / kmh * 100 else null
                set("Сейчас", v?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                    if (v == null) "л/100 км · едем > 5 км/ч" else "л/100 км", if (v != null && v < 0.05) C.GREEN else C.TEXT)
            },
            tile {
                val t = Live.trip
                set("За поездку", t?.lPer100?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                    t?.let { String.format(Locale.US, "л/100 км · %.2f л · %.1f км", it.fuelL, it.distanceKm) } ?: "л/100 км")
            },
            tile { set("Топливо в баке", x("fuelGal")?.let { String.format(Locale.US, "≈ %.0f л", it * 3.78541) } ?: if (na("fuelGal")) "н/д" else "—", "по датчику щитка") },
            tile { set("Пробег (ЭБУ)", fx("odoKm", "%.0f"), "км") },
        )

        fun tp(t: Tile, cap: String, p: String, tt: String) {
            val v = x(p)
            t.set(cap, fx(p, "%.2f бар"), "шина " + fx(tt, "%.0f°C"),
                if (v != null && (v < 1.9 || v > 3.0)) C.YELLOW else C.TEXT)
        }
        carSection(col, "Шины (TPMS)",
            tile { tp(this, "Перед лев.", "tpFL", "ttFL") }, tile { tp(this, "Перед прав.", "tpFR", "ttFR") },
            tile { tp(this, "Зад лев.", "tpRL", "ttRL") }, tile { tp(this, "Зад прав.", "tpRR", "ttRR") },
        )

        carSection(col, "Климат и счётчики ВВБ",
            tile { set("Салон / улица", fx("cabin", "%.0f°") + " / " + fx("ambient", "%.0f°"), "°C") },
            tile {
                set("Счётчики ЭБУ ВВБ", fx("cntLow", "%.0f"),
                    "низкий SOC · перегрев " + fx("cntHot", "%.0f") + " · высокий " + fx("cntHigh", "%.0f"))
            },
        )

        // Customisation
        val cc = card()
        cc.addView(sectionTitle("Настройки машины (как в Techstream)"))
        cc.addView(text(12f, C.MUTED).apply {
            text = "Работает с включённым зажиганием и запущенной записью. Перед изменением приложение читает и сохраняет исходное значение, после — проверяет. Если блок не ответил — ничего не пишется."
        })
        cc.addSpaced(text(15f, C.TEXT, bold = true).apply { text = "Пищалка заднего хода (внутри салона)" }, 12f)
        cc.addSpaced(btnRow(
            "Проверить" to { readCustom() },
            "Выключить" to { setReverse(off = true) },
            "Включить" to { setReverse(off = false) }), 6f)
        cc.addSpaced(text(15f, C.TEXT, bold = true).apply { text = "Напоминание о ремне безопасности" }, 14f)
        cc.addSpaced(btnRow(
            "Выключить" to { setSeatbelt(restore = false) },
            "Вернуть как было" to { setSeatbelt(restore = true) }), 6f)
        customText = text(12f, C.MUTED, mono = true)
        cc.addSpaced(customText, 10f)
        cc.addSpaced(text(12f, C.MUTED).apply {
            text = "Замки, свет, сигнализация и прочее из Techstream: команды для этих настроек нигде не опубликованы — вслепую не пишу, чтобы не сбить блок кузова."
        }, 10f)
        col.addSpaced(cc, 16f)
        return sv
    }

    private fun btnRow(vararg b: Pair<String, () -> Unit>): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        b.forEachIndexed { i, (label, f) ->
            val v = text(13f, C.TEXT, bold = true).apply {
                text = label; gravity = Gravity.CENTER
                setPadding(dp(6f), dp(11f), dp(6f), dp(11f))
                background = rounded(C.CARD2, dp(10f).toFloat())
                setOnClickListener { f() }
            }
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            if (i > 0) lp.leftMargin = dp(8f)
            addView(v, lp)
        }
    }

    private fun renderCar() {
        renderHeader()
        if (pages[1] == null) return
        carNote.text = when {
            !Live.running -> "Нажми «Старт». Данные обновляются по кругу, примерно раз в 10–20 секунд каждое."
            !Live.recording -> "Жду READY…"
            else -> "Обновляется по кругу. «н/д» — этот блок у твоей машины не отвечает."
        }
        carTiles.forEach { it.render() }
    }

    private fun hex(v: Int?) = v?.let { String.format("%02X", it) } ?: "нет ответа"

    private fun customLog(s: String) { customText.text = s }

    private fun readCustom() {
        customLog("Читаю…")
        Live.submit({ elm ->
            val r = Custom.read(elm, Custom.REVERSE); val b = Custom.read(elm, Custom.SEATBELT)
            r?.let { backup(Custom.REVERSE, it) }; b?.let { backup(Custom.SEATBELT, it) }
            "Задний ход: ${hex(r)}" + (r?.let { if (it and 0x40 != 0) " → пищалка ВЫКЛ" else " → пищалка ВКЛ" } ?: "") +
                "\nРемень: ${hex(b)}" + (b?.let { if (it == 0) " → напоминание ВЫКЛ" else " → включено" } ?: "") +
                backupLine()
        }) { customLog(it) }
    }

    private fun backup(id: String, v: Int) {
        if (!prefs().contains("bk_$id")) prefs().edit().putInt("bk_$id", v).apply()
    }

    private fun backupLine(): String {
        val a = if (prefs().contains("bk_AC")) hex(prefs().getInt("bk_AC", 0)) else "—"
        val b = if (prefs().contains("bk_A7")) hex(prefs().getInt("bk_A7", 0)) else "—"
        return "\nЗаводское (сохранено): задний ход $a · ремень $b"
    }

    private fun confirm(title: String, msg: String, ok: () -> Unit) {
        dlg().setTitle(title).setMessage(msg).setPositiveButton("Да") { _, _ -> ok() }.setNegativeButton("Отмена", null).show()
    }

    private fun setReverse(off: Boolean) = confirm(if (off) "Выключить пищалку?" else "Включить пищалку?",
        "Наружный сигнал (если есть) не меняется. Вернуть можно здесь же.") {
        customLog("Пишу…")
        Live.submit({ elm ->
            val cur = Custom.read(elm, Custom.REVERSE) ?: return@submit "Блок кузова (7C0) не ответил — ничего не записано."
            backup(Custom.REVERSE, cur)
            val want = if (off) cur or 0x40 else cur and 0x40.inv()
            if (want == cur) return@submit "Уже ${if (off) "выключено" else "включено"} (${hex(cur)})." + backupLine()
            val (now, raw) = Custom.write(elm, Custom.REVERSE, want)
            (if (now == want) "Готово: ${hex(cur)} → ${hex(now)}. Проверь, включив R." else "Не подтвердилось: было ${hex(cur)}, сейчас ${hex(now)}") +
                "\n(ответ: $raw)" + backupLine()
        }) { customLog(it) }
    }

    private fun setSeatbelt(restore: Boolean) {
        if (restore && !prefs().contains("bk_A7")) {
            dlg().setMessage("Исходное значение ещё не сохранено — значит, ничего и не менялось.").setPositiveButton("OK", null).show(); return
        }
        confirm(if (restore) "Вернуть напоминание о ремне?" else "Выключить напоминание о ремне?",
            if (restore) "Запишу сохранённое заводское значение." else "Отключит звук для водителя и пассажира. Исходное значение сохраню, чтобы вернуть.") {
            customLog("Пишу…")
            Live.submit({ elm ->
                val cur = Custom.read(elm, Custom.SEATBELT) ?: return@submit "Блок кузова (7C0) не ответил — ничего не записано."
                backup(Custom.SEATBELT, cur)
                val want = if (restore) prefs().getInt("bk_A7", cur) else 0
                if (want == cur) return@submit "Уже так (${hex(cur)})." + backupLine()
                val (now, raw) = Custom.write(elm, Custom.SEATBELT, want)
                (if (now == want) "Готово: ${hex(cur)} → ${hex(now)}" else "Не подтвердилось: было ${hex(cur)}, сейчас ${hex(now)}") +
                    "\n(ответ: $raw)" + backupLine()
            }) { customLog(it) }
        }
    }

    // ================= TRIPS =================

    private val dateFmt = SimpleDateFormat("d MMM, HH:mm", Locale("ru"))

    private fun buildTrips(): View {
        val (sv, col) = scrollPage()
        val trips = TripStore.all(this).reversed()
        if (trips.isEmpty()) {
            col.addSpaced(card().apply {
                addView(text(15f, C.TEXT, bold = true).apply { text = "Поездок пока нет" })
                addView(text(13f, C.MUTED).apply { text = "Нажми «Старт» и поезди: после каждой поездки здесь появится отчёт." })
            }, 4f)
            return sv
        }
        for (t in trips.take(60)) {
            val c = card()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(text(15f, C.TEXT, bold = true).apply { text = dateFmt.format(Date(t.start)) }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(text(13f, C.MUTED).apply {
                text = String.format(Locale.US, "%.0f мин · %.1f км", t.durationMin, t.distanceKm)
            })
            c.addView(top)
            val ch = chip()
            ch.setChip(t.verdict(), C.level(t.level()))
            c.addSpaced(LinearLayout(this).apply { addView(ch) }, 8f)
            c.addSpaced(text(13f, C.TEXT).apply {
                text = buildString {
                    append(String.format(Locale.US, "Разброс: среднее %.2f · макс %.2f V\n", t.spreadAvg, t.spreadMax))
                    append(String.format(Locale.US, "SOC %s → %s%%", f1(t.socStart, "%.0f"), f1(t.socEnd, "%.0f")))
                    val w = t.weakestTop()
                    if (w.isNotEmpty()) append(" · чаще отставали ${w.joinToString(", ") { "№$it" }}")
                    append("\n")
                    append("Темп. ВВБ ${if (t.battTempMaxF.isNaN()) "—" else String.format(Locale.US, "%.0f–%.0f°F", t.battTempMinF, t.battTempMaxF)}")
                    if (!t.coolantMaxC.isNaN()) append(String.format(Locale.US, " · ОЖ макс %.0f°C", t.coolantMaxC))
                    append(String.format(Locale.US, " · EV %.0f%%", t.evShare))
                    t.restingAux?.let { append(String.format(Locale.US, "\n12V в покое %.2f V", it)) }
                    t.lPer100?.let { append(String.format(Locale.US, "\nРасход ≈ %.1f л/100 км (%.2f л)", it, t.fuelL)) }
                    if (!t.invCoolMax.isNaN()) append(String.format(Locale.US, "\nИнвертор: ОЖ макс %.0f°C", t.invCoolMax))
                }
            }, 8f)
            c.setOnClickListener { tripDialog(t) }
            col.addSpaced(c, if (col.childCount == 0) 4f else 10f)
        }
        return sv
    }

    private fun tripDialog(t: TripStats) {
        val f = File(File(getExternalFilesDir(null), "logs"), t.file)
        val msg = buildString {
            append("Файл: ${t.file}\nСтрок: ${t.rows}\n\n")
            append("Средн. отклонение блоков от среднего, V:\n")
            for (i in 0 until 14) {
                append(String.format(Locale.US, "№%-2d %+.3f", i + 1, t.devAvg(i)))
                append(if (i % 2 == 1) "\n" else "     ")
            }
            if (t.lowEvents.sum() > 0) append("\nПросадки ≥0.33V: " + t.lowEvents.withIndex().filter { it.value > 0 }.joinToString(", ") { "№${it.index + 1}×${it.value}" })
            append(String.format(Locale.US, "\nТок: %.0f…%+.0f A", t.curMin, t.curMax))
        }
        val b = dlg().setTitle(dateFmt.format(Date(t.start))).setMessage(msg).setNegativeButton("Закрыть", null)
        if (f.exists()) b.setPositiveButton("Отправить лог") { _, _ -> share(listOf(f)) }
        b.show()
    }

    // ================= TRENDS =================

    private fun buildTrends(): View {
        val (sv, col) = scrollPage()
        val trips = TripStore.all(this).filter { it.rows >= 60 }.takeLast(30)
        val short = SimpleDateFormat("d.MM", Locale.US)
        val labels = if (trips.isEmpty()) emptyList() else listOf(short.format(Date(trips.first().start)), short.format(Date(trips.last().start)))

        col.addSpaced(card().apply {
            addView(text(13f, C.MUTED).apply {
                text = if (trips.size < 3) "Тренды появятся после 3+ поездок (сейчас ${trips.size})."
                       else "Последние ${trips.size} поездок. Смотри, не растёт ли линия и не краснеет ли один и тот же блок."
            })
        }, 4f)

        // Spread
        val c1 = card(); c1.addView(sectionTitle("Разброс блоков по поездкам, V"))
        c1.addView(LineChartView(this).apply {
            threshold = 1.0; thresholdLabel = "≈ порог чека"; fixedMin = 0.0; xLabels = labels
            series = listOf(
                Series("среднее", C.BLUE, trips.map { it.spreadAvg }),
                Series("максимум", C.ORANGE, trips.map { it.spreadMax }))
        })
        col.addSpaced(c1)

        // Heatmap
        val c2 = card(); c2.addView(sectionTitle("Кто отстаёт: блок × поездка"))
        c2.addView(HeatmapView(this).apply {
            columns = trips.map { t -> DoubleArray(14) { t.devAvg(it) } }
            xLabels = labels
        })
        if (trips.size >= 3) {
            val recent = trips.takeLast(10)
            val score = DoubleArray(14) { b -> recent.sumOf { it.devAvg(b) } / recent.size }
            val worst = score.withIndex().sortedBy { it.value }.take(3)
            c2.addSpaced(text(13f, C.TEXT).apply {
                text = "Слабее всех за последние ${recent.size}: " + worst.joinToString(", ") { String.format(Locale.US, "№%d (%+.3f V)", it.index + 1, it.value) }
            }, 6f)
        }
        col.addSpaced(c2)

        // IR
        val c3 = card(); c3.addView(sectionTitle("Внутреннее сопротивление, mΩ"))
        c3.addView(LineChartView(this).apply {
            xLabels = labels
            series = listOf(
                Series("среднее", C.BLUE, trips.map { t -> t.irAvg?.average() }),
                Series("худший блок", C.ORANGE, trips.map { t -> t.irAvg?.max()?.toDouble() }))
        })
        col.addSpaced(c3)

        // 12V
        val c4 = card(); c4.addView(sectionTitle("12V аккумулятор в покое, V"))
        c4.addView(LineChartView(this).apply {
            threshold = 12.2; thresholdLabel = "ниже — подсажен"; xLabels = labels
            series = listOf(Series("перед поездкой", C.GREEN, trips.map { it.restingAux }))
        })
        col.addSpaced(c4)

        // Engine
        val c5 = card(); c5.addView(sectionTitle("Двигатель: макс. темп. ОЖ, °C"))
        c5.addView(LineChartView(this).apply {
            threshold = 105.0; thresholdLabel = "перегрев"; xLabels = labels
            series = listOf(Series("ОЖ макс", C.RED, trips.map { if (it.coolantMaxC.isNaN()) null else it.coolantMaxC }))
        })
        col.addSpaced(c5)

        val c6 = card(); c6.addView(sectionTitle("Расход по поездкам, л/100 км"))
        c6.addView(LineChartView(this).apply {
            xLabels = labels; fixedMin = 0.0
            series = listOf(Series("расход", C.BLUE, trips.map { it.lPer100 }))
        })
        c6.addSpaced(text(12f, C.MUTED).apply { text = "Оценка по датчику расхода воздуха (MAF). Короткие поездки зимой всегда выше." }, 6f)
        col.addSpaced(c6)

        val c7 = card(); c7.addView(sectionTitle("Инвертор: макс. темп. ОЖ, °C"))
        c7.addView(LineChartView(this).apply {
            threshold = Extras.INV_COOL_WARN; thresholdLabel = "помпа?"; xLabels = labels
            series = listOf(Series("ОЖ инвертора", C.ORANGE, trips.map { if (it.invCoolMax.isNaN()) null else it.invCoolMax }))
        })
        col.addSpaced(c7)
        return sv
    }

    // ================= SERVICE =================

    private fun button(label: String, color: Int = C.CARD2, onClick: () -> Unit): TextView =
        text(15f, C.TEXT, bold = true).apply {
            text = label; gravity = Gravity.CENTER
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            background = rounded(color, dp(12f).toFloat())
            setOnClickListener { onClick() }
        }

    private fun buildService(): View {
        val (sv, col) = scrollPage()
        val c1 = card()
        c1.addView(sectionTitle("Адаптер"))
        c1.addView(text(15f).apply {
            text = prefs().getString("name", null)?.let { "$it  (${prefs().getString("mode", "auto")})" } ?: "Не выбран"
        })
        c1.addSpaced(button("Выбрать адаптер") { pickDevice() }, 10f)
        c1.addSpaced(button("Разрешить работу в фоне") { askBatteryExemption() }, 8f)
        col.addSpaced(c1, 4f)

        val c2 = card()
        c2.addView(sectionTitle("Диагностика"))
        c2.addView(button("Ошибки · freeze frame · терминал") { startActivity(Intent(this, ToolsActivity::class.java)) })
        c2.addSpaced(button("Отправить логи") { shareLogs() }, 8f)
        col.addSpaced(c2)

        val c3 = card()
        c3.addView(sectionTitle("Как пользоваться"))
        c3.addView(text(13f, C.MUTED).apply {
            text = "1. Закрой Dr. Prius — адаптер держит одно подключение.\n" +
                "2. Нажми «Старт» до того, как заведёшь машину: так запишется 12V в покое и холодный старт.\n" +
                "3. Запись идёт в фоне. Когда заглушишь, появится отчёт во вкладке «Поездки».\n" +
                "4. Если всплыла ошибка — не сбрасывай. Открой «Ошибки · freeze frame» и отправь файлы."
        })
        col.addSpaced(c3)
        return sv
    }

    // ================= actions =================

    private fun toggle() {
        if (Live.running) { MonitorService.stop(this); Handler(Looper.getMainLooper()).postDelayed({ renderHeader(); if (tab == 0) renderNow() }, 300); return }
        if (prefs().getString("addr", null) == null) { pickDevice(); return }
        if (!hasPerms()) { requestPerms(); return }
        MonitorService.start(this)
        Handler(Looper.getMainLooper()).postDelayed({ renderHeader(); if (tab == 0) renderNow() }, 300)
    }

    private fun neededPerms(): Array<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN; l += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            l += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }

    private fun hasPerms() = neededPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestPerms() {
        if (!hasPerms()) requestPermissions(neededPerms(), 1)
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            dlg().setMessage("Уже разрешено: система не будет усыплять запись.").setPositiveButton("OK", null).show()
            return
        }
        try {
            @SuppressLint("BatteryLife")
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            startActivity(i)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        if (!hasPerms()) { requestPerms(); return }
        val bm = getSystemService(BluetoothManager::class.java)
        val adapter = bm.adapter
        if (adapter == null || !adapter.isEnabled) {
            dlg().setMessage("Включи Bluetooth").setPositiveButton("OK", null).show(); return
        }
        val found = LinkedHashMap<String, Pair<String, String>>()   // addr -> (label, mode)
        adapter.bondedDevices?.forEach {
            val kind = when (it.type) { BluetoothDevice.DEVICE_TYPE_LE -> "ble"; BluetoothDevice.DEVICE_TYPE_CLASSIC -> "classic"; else -> "auto" }
            found[it.address] = Pair("${it.name ?: "?"}  [сопряжён, $kind]", kind)
        }
        val wait = dlg().setTitle("Ищу адаптер…").setMessage("6 секунд. Адаптер должен быть в разъёме.").setNegativeButton("Отмена", null).show()
        val scanner = adapter.bluetoothLeScanner
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                if (!found.containsKey(d.address)) {
                    val n = d.name ?: result.scanRecord?.deviceName ?: return
                    found[d.address] = Pair("$n  [BLE, ${result.rssi} dBm]", "ble")
                }
            }
        }
        try { scanner?.startScan(cb) } catch (_: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { scanner?.stopScan(cb) } catch (_: Exception) {}
            wait.dismiss()
            if (isFinishing) return@postDelayed
            val keys = found.keys.toList()
            if (keys.isEmpty()) {
                dlg().setMessage("Ничего не найдено. Проверь, что адаптер в разъёме и зажигание включено.").setPositiveButton("OK", null).show()
                return@postDelayed
            }
            val labels = keys.map { found[it]!!.first + "\n" + it }.toTypedArray()
            dlg().setTitle("Выбери адаптер (Viecar / OBD / V-LINK)")
                .setItems(labels) { _, which ->
                    val addr = keys[which]
                    val p = found[addr]!!
                    prefs().edit().putString("addr", addr).putString("name", p.first.substringBefore("  ")).putString("mode", p.second).apply()
                    showTab(tab)
                }.show()
        }, 6000)
    }

    private fun shareLogs() {
        val files = CsvLogger(this).listLogs()
        if (files.isEmpty()) {
            dlg().setMessage("Логов пока нет").setPositiveButton("OK", null).show(); return
        }
        val labels = files.map { "${it.name}  (${it.length() / 1024} KB)" }.toTypedArray()
        dlg().setTitle("Отправить лог")
            .setItems(labels) { _, which -> share(listOf(files[which])) }
            .setPositiveButton("Последние 5") { _, _ -> share(files.take(5)) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun share(files: List<File>) {
        val uris = ArrayList(files.map { androidx.core.content.FileProvider.getUriForFile(this, "com.ct200h.monitor.files", it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
                else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "text/csv"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Отправить"))
    }
}
