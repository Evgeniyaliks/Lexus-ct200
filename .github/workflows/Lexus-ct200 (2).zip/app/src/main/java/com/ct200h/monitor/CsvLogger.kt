package com.ct200h.monitor

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Writes CSV in the same column layout as Dr. Prius "BatteryMonitorLog" (plus extra columns at the end),
 * keeps a rolling buffer of recent rows, and saves a separate event file around incidents.
 */
class CsvLogger(private val ctx: Context) {
    private val dirLogs = File(ctx.getExternalFilesDir(null), "logs").apply { mkdirs() }
    private val stamp = SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US)
    private val fileStamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)

    private var writer: FileWriter? = null
    var currentFile: File? = null; private set

    private val buffer = ArrayDeque<String>()
    private val bufferMax = 600            // ~2-3 min of rows
    private var eventWriter: FileWriter? = null
    private var eventRowsLeft = 0

    companion object {
        val EXTRA_COLS = listOf("maf" to "MAF(g/s)", "load" to "Load(%)", "mg1" to "MG1(C)", "mg2" to "MG2(C)",
            "inv1" to "Inv MG1(C)", "inv2" to "Inv MG2(C)", "invCool" to "Inv Coolant(C)", "invPump" to "Inv Pump(rpm)",
            "hvFan" to "HV Fan(%)", "stft" to "STFT(%)", "ltft" to "LTFT(%)", "ambient" to "Ambient(C)")
        val HEADER: String = buildString {
            append("Vehicle Speed(MPH)")
            for (i in 1..14) append(",Vol#$i")
            for (i in 1..14) append(",IR#$i")
            append(",Batt Temp#1(F),Batt Temp#2(F),Batt Temp#3(F),SOC(%),Delta SOC(%),Current(Amp)")
            append(",Charge Limit(HP),Discharge Limit(HP),Aux volt,DateTime")
            append(",Intake Temp(F),ECU Weakest Block,Spread(V),Coolant(C),RPM,Event,DTC")
            for ((_, title) in EXTRA_COLS) append(",").append(title)
        }
    }

    fun startSession(): File {
        stop()
        val f = File(dirLogs, "CT200h_${fileStamp.format(Date())}.csv")
        writer = FileWriter(f, false).apply { write(HEADER + "\n"); flush() }
        currentFile = f
        buffer.clear()
        return f
    }

    private fun fmt(d: Double?, p: Int = 2): String = if (d == null) "" else String.format(Locale.US, "%.${p}f", d)

    fun row(s: Snapshot, event: String, dtc: String): String {
        val sb = StringBuilder()
        sb.append(fmt(s.speedMph, 1))
        for (v in s.blocks) sb.append(',').append(fmt(v, 3))
        for (i in 0 until 14) sb.append(',').append(s.ir?.get(i)?.toString() ?: "")
        val t = s.tempsF
        sb.append(',').append(fmt(t?.get(1), 1))
        sb.append(',').append(fmt(t?.get(2), 1))
        sb.append(',').append(fmt(t?.get(3), 1))
        sb.append(',').append(fmt(s.soc, 2))
        sb.append(',')                                   // Delta SOC: not available on Gen3 via this ECU
        sb.append(',').append(fmt(s.current, 2))
        sb.append(',').append(fmt(s.chargeLimHp, 1))
        sb.append(',').append(fmt(s.dischargeLimHp, 1))
        sb.append(',').append(fmt(s.aux, 2))
        sb.append(',').append(stamp.format(Date(s.time)))
        sb.append(',').append(fmt(t?.get(0), 1))
        sb.append(',').append(s.ecuWeakest?.toString() ?: "")
        sb.append(',').append(fmt(s.spread, 3))
        sb.append(',').append(fmt(s.coolantC, 0))
        sb.append(',').append(s.rpm?.toString() ?: "")
        sb.append(',').append(event.replace(',', ';'))
        sb.append(',').append(dtc.replace(',', ' '))
        for ((k, _) in EXTRA_COLS) sb.append(',').append(fmt(Extras.get(k), 1))
        return sb.toString()
    }

    fun write(s: Snapshot, event: String, dtc: String) {
        val line = row(s, event, dtc)
        writer?.apply { write(line); write("\n") }
        buffer.addLast(line)
        while (buffer.size > bufferMax) buffer.removeFirst()
        eventWriter?.let { ew ->
            ew.write(line); ew.write("\n")
            eventRowsLeft--
            if (eventRowsLeft <= 0) { ew.close(); eventWriter = null }
        }
    }

    fun flush() { writer?.flush(); eventWriter?.flush() }

    /** Saves the buffered past rows plus the next [afterRows] rows to a separate event file. */
    fun captureEvent(label: String, afterRows: Int = 240): File? {
        if (eventWriter != null) { eventRowsLeft = maxOf(eventRowsLeft, afterRows); return null }
        val safe = label.replace(Regex("[^A-Za-z0-9_]"), "_")
        val f = File(dirLogs, "EVENT_${fileStamp.format(Date())}_$safe.csv")
        val w = FileWriter(f, false)
        w.write(HEADER + "\n")
        for (l in buffer) { w.write(l); w.write("\n") }
        w.flush()
        eventWriter = w
        eventRowsLeft = afterRows
        return f
    }

    fun appendNote(text: String) {
        try {
            FileWriter(File(dirLogs, "events.txt"), true).use {
                it.write("${stamp.format(Date())}  $text\n")
            }
        } catch (_: Exception) {}
    }

    fun stop() {
        try { writer?.flush(); writer?.close() } catch (_: Exception) {}
        try { eventWriter?.close() } catch (_: Exception) {}
        writer = null; eventWriter = null; currentFile = null
    }

    fun listLogs(): List<File> =
        (dirLogs.listFiles()?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }
}
