package com.ct200h.monitor

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue

/** One row of data. Values carry forward between polls (like Dr. Prius). */
class Snapshot(
    val time: Long,
    val blocks: DoubleArray,
    val ir: IntArray?,
    val tempsF: DoubleArray?,      // intake, T1, T2, T3
    val soc: Double?,
    val current: Double?,
    val chargeLimHp: Double?,
    val dischargeLimHp: Double?,
    val aux: Double?,
    val speedMph: Double?,
    val ecuWeakest: Int?,
    val coolantC: Double?,
    val rpm: Int?,
) {
    val spread: Double get() = blocks.max() - blocks.min()
    val avg: Double get() = blocks.average()
    val minBlock: Int get() = blocks.indices.minBy { blocks[it] } + 1
    val maxBlock: Int get() = blocks.indices.maxBy { blocks[it] } + 1
    val lowDev: Double get() = avg - blocks.min()
    val battTempMaxF: Double? get() = tempsF?.let { maxOf(it[1], it[2], it[3]) }
}

/** A job the UI asks the service to run on the adapter between polls. */
class Job(val work: (Elm) -> String, val done: (String) -> Unit)

object Live {
    @Volatile var status: String = "Остановлено"
    @Volatile var snap: Snapshot? = null
    @Volatile var logFile: String? = null
    @Volatile var rows: Int = 0
    @Volatile var running: Boolean = false
    @Volatile var connected: Boolean = false
    @Volatile var recording: Boolean = false
    /** Active codes (stored + pending). */
    @Volatile var dtcs: List<String> = emptyList()
    /** Permanent codes: history the ECU clears by itself after a passed self-test. */
    @Volatile var permanentDtcs: List<String> = emptyList()
    @Volatile var trip: TripStats? = null
    /** Last 12V reading taken while the car was off / before READY. */
    @Volatile var restingAux: Double? = null
    @Volatile var restingAuxTime: Long = 0L
    val events = CopyOnWriteArrayList<String>()
    val jobs = LinkedBlockingQueue<Job>()

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun changed() { main.post { listeners.forEach { it() } } }

    fun event(text: String) {
        events.add(0, text)
        while (events.size > 50) events.removeAt(events.size - 1)
        changed()
    }

    /** Queue a job; if the service isn't connected, answer immediately. */
    fun submit(work: (Elm) -> String, done: (String) -> Unit) {
        if (!connected) { main.post { done("Нет связи с адаптером. Нажми «Старт» и дождись подключения.") }; return }
        jobs.add(Job(work) { r -> main.post { done(r) } })
    }
}
