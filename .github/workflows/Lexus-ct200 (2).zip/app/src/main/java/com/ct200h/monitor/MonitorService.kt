package com.ct200h.monitor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import java.util.Locale

/**
 * Foreground service: keeps the adapter connection and logs in the background (screen off, app minimized).
 * Auto mode: waits for the car to answer, starts a new log file on READY, closes it when the car goes quiet.
 */
class MonitorService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val PREFS = "prefs"
        private const val CH_RUN = "run"
        private const val CH_ALERT = "alert"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, MonitorService::class.java).setAction(ACTION_STOP))
        }
    }

    @Volatile private var running = false
    private var worker: Thread? = null
    private var transport: Transport? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var logger: CsvLogger

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        logger = CsvLogger(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Запись", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Ошибки ВВБ", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val n = buildNotification("Запуск…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (!running) {
            running = true
            Live.running = true
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ct200h:monitor").apply { acquire() }
            worker = Thread({ mainLoop() }, "monitor").apply { start() }
        }
        return START_STICKY
    }

    private fun shutdown() {
        running = false
        Live.running = false
        transport?.close()
        worker?.interrupt()
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        setStatus("Остановлено")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        Live.running = false
        transport?.close()
        logger.stop()
        super.onDestroy()
    }

    // ---------- connection ----------

    @SuppressLint("MissingPermission")
    private fun connect(): Transport {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val addr = prefs.getString("addr", null) ?: throw TransportException("Адаптер не выбран")
        val mode = prefs.getString("mode", "auto") ?: "auto"
        val bm = getSystemService(BluetoothManager::class.java)
        val adapter = bm.adapter ?: throw TransportException("Нет Bluetooth")
        if (!adapter.isEnabled) throw TransportException("Bluetooth выключен")
        val dev: BluetoothDevice = adapter.getRemoteDevice(addr)
        try { adapter.cancelDiscovery() } catch (_: Exception) {}
        return when (mode) {
            "classic" -> ClassicTransport.connect(dev)
            "ble" -> BleTransport.connect(this, dev)
            else -> {
                val bonded = adapter.bondedDevices?.any { it.address == addr } == true
                if (bonded && dev.type != BluetoothDevice.DEVICE_TYPE_LE) {
                    try { ClassicTransport.connect(dev) } catch (e: Exception) { BleTransport.connect(this, dev) }
                } else {
                    BleTransport.connect(this, dev)
                }
            }
        }
    }

    private fun mainLoop() {
        while (running) {
            setStatus("Подключаюсь к адаптеру…")
            val t = try { connect() } catch (e: Exception) {
                setStatus("Адаптер недоступен (${e.message}). Повтор через 10 с")
                sleep(10_000); continue
            }
            transport = t
            try {
                val elm = Elm(t)
                elm.init()
                Live.connected = true
                setStatus("Адаптер подключён. Жду READY…")
                pollLoop(elm)
            } catch (e: Exception) {
                if (running) {
                    setStatus("Связь потеряна: ${e.message}")
                    Live.event("Связь с адаптером потеряна")
                }
            } finally {
                Live.connected = false
                t.close()
                endSession("связь потеряна")
            }
            sleep(3000)
        }
    }

    // ---------- polling ----------

    private var session = false
    private var ir: IntArray? = null
    private var temps: DoubleArray? = null
    private var soc: Double? = null
    private var lastSoc: Double? = null
    private var aux: Double? = null
    private var speed: Double? = null
    private var weakest: Int? = null
    private var current: Double? = null
    private var chg: Double? = null
    private var dis: Double? = null
    private var coolant: Double? = null
    private var rpm: Int? = null
    private var socHeader = "7E2"
    private val knownDtc = mutableSetOf<String>()
    private var lastCaptureAt = 0L
    private var coolantAlerted = false
    private var invAlerted = false
    private var trip: TripStats? = null

    private fun pollLoop(elm: Elm) {
        var fails = 0
        var iter = 0
        var lastDtcCheck = 0L
        var lastNotif = 0L
        var lastRestRead = 0L
        while (running) {
            runJobs(elm)

            val blocks = Decode.blocks(elm.request("7E2", "2181"))
            if (blocks == null) {
                fails++
                if (session && fails >= 8) endSession("машину заглушили")
                if (!session) {
                    // Car off: the adapter reads the 12V battery at rest
                    val now = System.currentTimeMillis()
                    if (now - lastRestRead > 30_000) {
                        lastRestRead = now
                        elm.batteryVoltage()?.let { Live.restingAux = it; Live.restingAuxTime = now }
                    }
                    setStatus("Адаптер подключён. Жду READY…"); sleep(2000)
                } else sleep(300)
                continue
            }
            fails = 0
            if (!session) startSession(elm)

            Decode.currentLimits(elm.request("7E2", "2198"))?.let { current = it.first; chg = it.second; dis = it.third }

            if (iter % 4 == 0) {
                Decode.temps(elm.request("7E2", "2187"))?.let { temps = it }
                var s = Decode.soc(elm.request(socHeader, "015B"))
                if (s == null && socHeader == "7E2") { socHeader = "7DF"; s = Decode.soc(elm.request(socHeader, "015B")) }
                if (s != null) soc = s
                Decode.speedMph(elm.request("7E0", "010D"))?.let { speed = it }
                elm.batteryVoltage()?.let {
                    aux = it
                    // First reading of the trip, before the DC-DC converter kicks in, is the rest voltage
                    if (iter == 0 && it < 13.0) {
                        Live.restingAux = it; Live.restingAuxTime = System.currentTimeMillis()
                        trip?.restingAux = it
                    }
                }
            }
            if (iter % 4 == 2) {
                coolant = Decode.coolantC(elm.request("7E0", "0105")) ?: coolant
                rpm = Decode.rpm(elm.request("7E0", "010C")) ?: rpm
                elm.request("7E0", "0110")?.takeIf { it.size >= 2 }?.let { Extras.values["maf"] = it.u16(0) / 100.0 }
            }
            // Non-battery data: one slow request every other loop
            if (iter % 2 == 1) Extras.pollOne(elm)
            if (iter % 60 == 0) {
                Decode.resistances(elm.request("7E2", "2195"))?.let { ir = it }
                Decode.weakest(elm.request("7E2", "2192"))?.let { weakest = it }
            }

            val now = System.currentTimeMillis()
            var dtcText = ""
            val events = mutableListOf<String>()
            if (now - lastDtcCheck > 10_000) {
                lastDtcCheck = now
                val found = readDtcs(elm)
                Live.dtcs = found
                dtcText = found.joinToString(" ")
                val fresh = found.filter { it !in knownDtc }
                if (fresh.isNotEmpty()) {
                    knownDtc.addAll(fresh)
                    trip?.dtcs?.addAll(fresh)
                    events.add("DTC " + fresh.joinToString(" "))
                    alert("Ошибка: ${fresh.joinToString(", ")}", "Лог сохранён. Не сбрасывай ошибку, пока не скинешь файлы.")
                    capture("DTC_" + fresh.joinToString("_"), force = true)
                }
            }

            val snap = Snapshot(now, blocks, ir, temps, soc, current, chg, dis, aux, speed, weakest, coolant, rpm)
            val low = snap.lowDev
            if (snap.spread >= 0.5) events.add(String.format(Locale.US, "SPREAD %.2fV min#%d max#%d", snap.spread, snap.minBlock, snap.maxBlock))
            var lowBlock: Int? = null
            if (low >= 0.33) {
                lowBlock = snap.minBlock
                events.add(String.format(Locale.US, "LOW_BLOCK #%d -%.2fV", snap.minBlock, low))
                capture("LOW_BLOCK_${snap.minBlock}")
            }
            val s = soc
            val ls = lastSoc
            var socJump = false
            if (s != null && ls != null && Math.abs(s - ls) > 3.0) {
                socJump = true
                events.add(String.format(Locale.US, "SOC_JUMP %.1f->%.1f", ls, s))
                capture("SOC_JUMP", force = true)
            }
            lastSoc = s

            val c = coolant
            if (c != null && c >= 105 && !coolantAlerted) {
                coolantAlerted = true
                events.add(String.format(Locale.US, "COOLANT %.0fC", c))
                alert(String.format(Locale.US, "Двигатель горячий: %.0f°C", c), "Проверь помпу (P261B) и уровень антифриза.")
            }
            if (c != null && c < 100) coolantAlerted = false

            val ic = Extras.get("invCool")
            if (ic != null && ic >= Extras.INV_COOL_WARN && !invAlerted) {
                invAlerted = true
                events.add(String.format(Locale.US, "INV_COOLANT %.0fC", ic))
                alert(String.format(Locale.US, "Инвертор горячий: %.0f°C", ic), "Проверь помпу инвертора и уровень его антифриза (бачок слева).")
            }
            if (ic != null && ic < Extras.INV_COOL_WARN - 10) invAlerted = false

            trip?.add(snap, lowBlock, socJump)
            trip?.addExtras(now, Extras.values)
            Live.trip = trip

            val ev = events.joinToString(" | ")
            logger.write(snap, ev, dtcText)
            Live.snap = snap
            Live.rows++
            if (events.any { !it.startsWith("SPREAD") }) {
                Live.event("${java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(now)}  $ev")
                logger.appendNote(ev)
            }
            Live.changed()

            if (iter % 20 == 0) logger.flush()
            if (now - lastNotif > 5000) {
                lastNotif = now
                updateNotification(String.format(Locale.US, "Запись · SOC %s · разброс %.2fV · %d строк",
                    soc?.let { String.format(Locale.US, "%.0f%%", it) } ?: "—", snap.spread, Live.rows))
            }
            iter++
        }
    }

    /** Active codes (stored + pending). Permanent codes go to Live.permanentDtcs. */
    private fun readDtcs(elm: Elm): List<String> {
        val out = LinkedHashSet<String>()
        val perm = LinkedHashSet<String>()
        for (h in listOf("7E2", "7E0")) {
            Decode.dtcs(elm.request(h, "03")).forEach { out.add(it) }
            Decode.dtcs(elm.request(h, "07")).forEach { out.add("$it(ож.)") }
            Decode.dtcs(elm.request(h, "0A")).forEach { perm.add(it) }
        }
        Live.permanentDtcs = perm.toList()
        return out.toList()
    }

    private fun capture(label: String, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastCaptureAt < 60_000) return
        lastCaptureAt = now
        logger.captureEvent(label)?.let { Live.event("Сохранён отрезок: ${it.name}") }
    }

    private fun startSession(elm: Elm) {
        val f = logger.startSession()
        session = true
        Live.logFile = f.name
        Live.rows = 0
        Live.recording = true
        lastSoc = null
        coolantAlerted = false
        invAlerted = false
        Extras.reset()
        val t = TripStats(System.currentTimeMillis(), f.name)
        // A rest reading taken in the last 10 minutes counts for this trip
        if (System.currentTimeMillis() - Live.restingAuxTime < 600_000) t.restingAux = Live.restingAux
        trip = t
        Live.trip = t
        // Errors already stored when the car started are recorded but don't trigger alerts
        knownDtc.clear()
        val existing = readDtcs(elm)
        knownDtc.addAll(existing)
        Live.dtcs = existing
        if (existing.isNotEmpty()) {
            Live.event("При старте уже есть ошибки: ${existing.joinToString(", ")}")
            logger.appendNote("Ошибки при старте: ${existing.joinToString(", ")}")
        }
        Live.event("Старт записи: ${f.name}")
        setStatus("Запись идёт")
    }

    private fun endSession(reason: String) {
        if (!session) return
        session = false
        Live.recording = false
        logger.stop()
        trip?.let { t ->
            if (t.rows >= 20) {
                TripStore.save(this, t)
                val title = String.format(Locale.US, "Поездка %.0f мин: %s", t.durationMin, t.verdict())
                val text = String.format(Locale.US, "Разброс до %.2fV · SOC %.0f→%.0f%%", t.spreadMax, t.socStart ?: 0.0, t.socEnd ?: 0.0)
                tripNotification(title, text)
                Live.event(title)
            }
        }
        trip = null
        Live.event("Запись остановлена: $reason")
        Live.logFile = null
        setStatus("Жду READY…")
    }

    private fun runJobs(elm: Elm) {
        while (true) {
            val j = Live.jobs.poll() ?: break
            val r = try { j.work(elm) } catch (e: Exception) { "Ошибка: ${e.message}" }
            j.done(r)
        }
    }

    // ---------- helpers ----------

    private fun setStatus(s: String) {
        Live.status = s
        Live.changed()
        updateNotification(s)
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("CT200h Монитор")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!running) return
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {}
    }

    private fun tripNotification(title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java).putExtra("tab", 2),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(4, n)
        } catch (_: Exception) {}
    }

    private fun alert(title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {}
    }
}
