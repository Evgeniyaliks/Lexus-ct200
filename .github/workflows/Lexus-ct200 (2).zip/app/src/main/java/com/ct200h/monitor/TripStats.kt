package com.ct200h.monitor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Running statistics for one trip (READY on -> READY off), saved as one JSON line per trip. */
class TripStats(val start: Long, val file: String) {
    var end: Long = start
    var rows = 0
    var spreadSum = 0.0
    var spreadMax = 0.0
    var over05 = 0
    var lowEvents = IntArray(14)
    var weakCount = IntArray(14)
    var devSum = DoubleArray(14)
    var socStart: Double? = null
    var socEnd: Double? = null
    var socMin = Double.NaN
    var socMax = Double.NaN
    var curMin = 0.0
    var curMax = 0.0
    var battTempMinF = Double.NaN
    var battTempMaxF = Double.NaN
    var coolantMaxC = Double.NaN
    var auxMinRun = Double.NaN
    var restingAux: Double? = null
    var movingRows = 0
    var evRows = 0
    var distanceMi = 0.0
    var irAvg: IntArray? = null
    var dtcs = mutableListOf<String>()
    var socJumps = 0
    var fuelL = 0.0
    var invCoolMax = Double.NaN
    var invMax = Double.NaN
    var mgMax = Double.NaN
    var ltft: Double? = null
    var ambient: Double? = null
    private var lastT = 0L
    private var lastFuelT = 0L

    val distanceKm: Double get() = distanceMi * 1.609344
    /** L/100 km, only when the trip is long enough to mean something. */
    val lPer100: Double? get() = if (distanceKm >= 2 && fuelL > 0) fuelL / distanceKm * 100 else null

    /** Integrates fuel from MAF and takes max of hybrid temps. Called each loop with the latest extras. */
    fun addExtras(now: Long, x: Map<String, Double>) {
        val maf = x["maf"]
        if (maf != null && lastFuelT != 0L) {
            val dt = (now - lastFuelT) / 3_600_000.0
            if (dt < 0.01) fuelL += Fuel.galPerHour(maf) * 3.78541 * dt
        }
        lastFuelT = now
        fun mx(cur: Double, v: Double?) = if (v == null) cur else if (cur.isNaN()) v else maxOf(cur, v)
        invCoolMax = mx(invCoolMax, x["invCool"])
        invMax = mx(invMax, listOfNotNull(x["inv1"], x["inv2"]).maxOrNull())
        mgMax = mx(mgMax, listOfNotNull(x["mg1"], x["mg2"]).maxOrNull())
        x["ltft"]?.let { ltft = it }
        x["ambient"]?.let { ambient = it }
    }

    val durationMin: Double get() = (end - start) / 60000.0
    val spreadAvg: Double get() = if (rows == 0) 0.0 else spreadSum / rows
    val evShare: Double get() = if (movingRows == 0) 0.0 else evRows * 100.0 / movingRows
    fun devAvg(i: Int): Double = if (rows == 0) 0.0 else devSum[i] / rows

    fun add(s: Snapshot, lowBlock: Int?, socJump: Boolean) {
        rows++
        end = s.time
        val sp = s.spread
        spreadSum += sp
        if (sp > spreadMax) spreadMax = sp
        if (sp >= 0.5) over05++
        weakCount[s.minBlock - 1]++
        val a = s.avg
        for (i in 0 until 14) devSum[i] += s.blocks[i] - a
        if (lowBlock != null) lowEvents[lowBlock - 1]++
        if (socJump) socJumps++
        s.soc?.let {
            if (socStart == null) socStart = it
            socEnd = it
            socMin = if (socMin.isNaN()) it else minOf(socMin, it)
            socMax = if (socMax.isNaN()) it else maxOf(socMax, it)
        }
        s.current?.let { curMin = minOf(curMin, it); curMax = maxOf(curMax, it) }
        s.battTempMaxF?.let {
            battTempMaxF = if (battTempMaxF.isNaN()) it else maxOf(battTempMaxF, it)
            battTempMinF = if (battTempMinF.isNaN()) it else minOf(battTempMinF, it)
        }
        s.coolantC?.let { coolantMaxC = if (coolantMaxC.isNaN()) it else maxOf(coolantMaxC, it) }
        s.aux?.let { if (rows > 10) auxMinRun = if (auxMinRun.isNaN()) it else minOf(auxMinRun, it) }
        val sp2 = s.speedMph
        if (sp2 != null && sp2 > 1.0) {
            movingRows++
            val r = s.rpm
            if (r != null && r < 100) evRows++
            if (lastT != 0L) distanceMi += sp2 * ((s.time - lastT) / 3_600_000.0)
        }
        lastT = s.time
        s.ir?.let { irAvg = it.copyOf() }
    }

    /** 0 = ok, 1 = attention, 2 = problem */
    fun level(): Int = when {
        dtcs.isNotEmpty() || socJumps > 0 -> 2
        lowEvents.sum() > 3 || spreadMax >= 1.0 -> 1
        (!coolantMaxC.isNaN() && coolantMaxC >= 105) -> 1
        (restingAux ?: 13.0) < 12.2 -> 1
        (!invCoolMax.isNaN() && invCoolMax >= Extras.INV_COOL_WARN) -> 1
        else -> 0
    }

    fun verdict(): String {
        val parts = mutableListOf<String>()
        if (dtcs.isNotEmpty()) parts += "ошибка ${dtcs.joinToString(", ")}"
        if (socJumps > 0) parts += "скачок SOC"
        val lows = lowEvents.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }
        if (lows.isNotEmpty() && lowEvents.sum() > 3) parts += "отставал блок №${lows.first().index + 1}"
        if (spreadMax >= 1.0) parts += String.format(Locale.US, "разброс до %.2fV", spreadMax)
        if (!coolantMaxC.isNaN() && coolantMaxC >= 105) parts += String.format(Locale.US, "ОЖ %.0f°C", coolantMaxC)
        restingAux?.let { if (it < 12.2) parts += String.format(Locale.US, "12V %.2fV в покое", it) }
        if (!invCoolMax.isNaN() && invCoolMax >= Extras.INV_COOL_WARN) parts += String.format(Locale.US, "ОЖ инвертора %.0f°C", invCoolMax)
        return if (parts.isEmpty()) "Батарея в норме" else parts.joinToString(" · ").replaceFirstChar { it.uppercase() }
    }

    fun weakestTop(n: Int = 3): List<Int> =
        weakCount.withIndex().sortedByDescending { it.value }.take(n).filter { it.value > 0 }.map { it.index + 1 }

    fun toJson(): JSONObject = JSONObject().apply {
        put("start", start); put("end", end); put("file", file); put("rows", rows)
        put("spreadSum", spreadSum); put("spreadMax", spreadMax); put("over05", over05)
        put("lowEvents", JSONArray(lowEvents.toList())); put("weakCount", JSONArray(weakCount.toList()))
        put("devSum", JSONArray(devSum.toList()))
        socStart?.let { put("socStart", it) }; socEnd?.let { put("socEnd", it) }
        putNum("socMin", socMin); putNum("socMax", socMax)
        put("curMin", curMin); put("curMax", curMax)
        putNum("tMin", battTempMinF); putNum("tMax", battTempMaxF); putNum("coolMax", coolantMaxC)
        putNum("auxMin", auxMinRun); restingAux?.let { put("resting", it) }
        put("moving", movingRows); put("ev", evRows); put("dist", distanceMi)
        irAvg?.let { put("ir", JSONArray(it.toList())) }
        put("dtcs", JSONArray(dtcs)); put("socJumps", socJumps)
        put("fuelL", fuelL); putNum("invCoolMax", invCoolMax); putNum("invMax", invMax); putNum("mgMax", mgMax)
        ltft?.let { put("ltft", it) }; ambient?.let { put("ambient", it) }
    }

    private fun JSONObject.putNum(k: String, v: Double) { if (!v.isNaN()) put(k, v) }

    companion object {
        fun fromJson(o: JSONObject): TripStats {
            val t = TripStats(o.getLong("start"), o.optString("file"))
            t.end = o.optLong("end", t.start); t.rows = o.optInt("rows")
            t.spreadSum = o.optDouble("spreadSum", 0.0); t.spreadMax = o.optDouble("spreadMax", 0.0)
            t.over05 = o.optInt("over05")
            o.optJSONArray("lowEvents")?.let { a -> t.lowEvents = IntArray(14) { a.optInt(it) } }
            o.optJSONArray("weakCount")?.let { a -> t.weakCount = IntArray(14) { a.optInt(it) } }
            o.optJSONArray("devSum")?.let { a -> t.devSum = DoubleArray(14) { a.optDouble(it, 0.0) } }
            if (o.has("socStart")) t.socStart = o.getDouble("socStart")
            if (o.has("socEnd")) t.socEnd = o.getDouble("socEnd")
            t.socMin = o.optDouble("socMin"); t.socMax = o.optDouble("socMax")
            t.curMin = o.optDouble("curMin", 0.0); t.curMax = o.optDouble("curMax", 0.0)
            t.battTempMinF = o.optDouble("tMin"); t.battTempMaxF = o.optDouble("tMax")
            t.coolantMaxC = o.optDouble("coolMax"); t.auxMinRun = o.optDouble("auxMin")
            if (o.has("resting")) t.restingAux = o.getDouble("resting")
            t.movingRows = o.optInt("moving"); t.evRows = o.optInt("ev"); t.distanceMi = o.optDouble("dist", 0.0)
            o.optJSONArray("ir")?.let { a -> t.irAvg = IntArray(14) { a.optInt(it) } }
            o.optJSONArray("dtcs")?.let { a -> for (i in 0 until a.length()) t.dtcs.add(a.getString(i)) }
            t.socJumps = o.optInt("socJumps")
            t.fuelL = o.optDouble("fuelL", 0.0)
            t.invCoolMax = o.optDouble("invCoolMax"); t.invMax = o.optDouble("invMax"); t.mgMax = o.optDouble("mgMax")
            if (o.has("ltft")) t.ltft = o.getDouble("ltft")
            if (o.has("ambient")) t.ambient = o.getDouble("ambient")
            return t
        }
    }
}

object TripStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "trips.jsonl")

    fun save(ctx: Context, t: TripStats) {
        try { file(ctx).appendText(t.toJson().toString() + "\n") } catch (_: Exception) {}
    }

    /** Oldest first. */
    fun all(ctx: Context): List<TripStats> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        return f.readLines().mapNotNull { l ->
            try { if (l.isBlank()) null else TripStats.fromJson(JSONObject(l)) } catch (_: Exception) { null }
        }
    }
}
