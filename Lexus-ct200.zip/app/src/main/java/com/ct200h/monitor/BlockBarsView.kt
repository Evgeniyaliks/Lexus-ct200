package com.ct200h.monitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import java.util.Locale

/** 14 bars: deviation of each block from the pack average. Red = lagging ≥0.33V. */
class BlockBarsView(ctx: Context) : View(ctx) {
    var blocks: DoubleArray? = null
        set(v) { field = v; invalidate() }

    private val dp = ctx.resources.displayMetrics.density
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY; textSize = 10 * dp; textAlign = Paint.Align.CENTER
    }
    private val axis = Paint().apply { color = Color.GRAY; strokeWidth = 1 * dp }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (190 * dp).toInt())
    }

    override fun onDraw(c: Canvas) {
        val b = blocks ?: run {
            c.drawText("нет данных", width / 2f, height / 2f, text); return
        }
        val avg = b.average()
        val scale = 0.6                                  // ±0.6 V full height
        val top = 16 * dp
        val bottom = height - 28 * dp
        val mid = (top + bottom) / 2
        val half = (bottom - top) / 2
        val slot = width / 14f
        c.drawLine(0f, mid, width.toFloat(), mid, axis)
        val minIdx = b.indices.minBy { b[it] }
        for (i in 0 until 14) {
            val dev = b[i] - avg
            val h = (dev / scale).coerceIn(-1.0, 1.0).toFloat() * half
            bar.color = when {
                -dev >= 0.33 -> Color.rgb(230, 60, 60)
                i == minIdx -> Color.rgb(240, 190, 40)
                else -> Color.rgb(60, 190, 110)
            }
            val x0 = i * slot + slot * 0.18f
            val x1 = (i + 1) * slot - slot * 0.18f
            if (h >= 0) c.drawRect(x0, mid - h, x1, mid, bar) else c.drawRect(x0, mid, x1, mid - h, bar)
            c.drawText("${i + 1}", i * slot + slot / 2, height - 14 * dp, text)
            c.drawText(String.format(Locale.US, "%.2f", b[i]), i * slot + slot / 2, height - 2 * dp, text.apply { textSize = 7.5f * dp })
            text.textSize = 10 * dp
        }
        c.drawText(String.format(Locale.US, "отклонение от среднего %.2f V (шкала ±%.1f V)", avg, scale), width / 2f, 11 * dp, text)
    }
}
