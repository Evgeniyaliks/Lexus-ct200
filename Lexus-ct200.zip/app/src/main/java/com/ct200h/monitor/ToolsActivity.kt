package com.ct200h.monitor

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Error codes, freeze-frame attempts, clear codes, raw ELM terminal. Output can be saved & shared. */
class ToolsActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var scroll: ScrollView
    private val dp get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt())
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(btn("Прочитать ошибки (все блоки)") { readCodes() })
        root.addView(btn("Freeze frame (эксперимент)") { freezeFrame() })
        root.addView(btn("Опрос неизвестных параметров (для анализа)") { probe() })

        val termRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply {
            hint = "команда, напр. ATSH7E2 или 2181"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            typeface = Typeface.MONOSPACE
        }
        termRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        termRow.addView(btn("Отпр.") {
            val c = input.text.toString().trim()
            if (c.isNotEmpty()) run("> $c") { it.terminal(c) }
        })
        root.addView(termRow)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(btn("Сохранить и отправить") { saveAndShare() }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(btn("Сбросить ошибки") { confirmClear() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom)

        out = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { addView(out) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        log("Подсказка: запись на главном экране должна быть запущена (адаптер подключён).\n" +
            "Ошибку не сбрасывай, пока не нажмёшь «Сохранить и отправить».")
    }

    private fun log(s: String) {
        out.append(s + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun run(title: String, work: (Elm) -> String) {
        log("\n$title …")
        Live.submit(work) { log(it) }
    }

    private val ecus = listOf("7E0" to "двигатель", "7E2" to "гибрид/ВВБ", "7E3" to "ЭБУ батареи")

    private fun readCodes() = run("Чтение ошибок") { elm ->
        buildString {
            for ((h, name) in ecus) {
                append("[$h $name]\n")
                for ((mode, label) in listOf("03" to "сохранённые", "07" to "ожидающие", "0A" to "постоянные")) {
                    val raw = elm.requestRaw(h, mode)
                    val prefix = String.format("%02X", mode.toInt(16) + 0x40)
                    val codes = Decode.dtcs(Hex.extractAfter(raw, prefix))
                    append("  $label: ${if (codes.isEmpty()) "нет" else codes.joinToString(", ")}   (raw: ${raw.replace('\n', ' ')})\n")
                }
            }
        }
    }

    /**
     * Generic OBD freeze frame (mode 02) plus Toyota enhanced requests.
     * Toyota's enhanced freeze-frame format for this ECU isn't publicly documented, so raw answers are shown
     * for later decoding.
     */
    private fun freezeFrame() = run("Freeze frame") { elm ->
        buildString {
            for (h in listOf("7E2", "7E0")) {
                append("[$h] стандартный OBD (режим 02)\n")
                for ((pid, name) in listOf("02" to "код, вызвавший снимок", "5B" to "SOC", "0D" to "скорость",
                        "05" to "темп. ОЖ", "0C" to "обороты", "42" to "напряжение ЭБУ")) {
                    val raw = elm.requestRaw(h, "02${pid}00")
                    val b = Hex.extractAfter(raw, "42$pid")
                    val v = when {
                        b == null -> "нет"
                        pid == "02" && b.size >= 3 -> Decode.dtcs(byteArrayOf(b[1], b[2])).joinToString().ifEmpty { "нет" }
                        pid == "5B" && b.size >= 2 -> String.format(Locale.US, "%.1f%%", b.u8(1) * 100 / 255.0)
                        pid == "0D" && b.size >= 2 -> "${(b.u8(1) * 0.621371).toInt()} mph"
                        pid == "05" && b.size >= 2 -> "${b.u8(1) - 40} °C"
                        pid == "0C" && b.size >= 3 -> "${b.u16(1) / 4} rpm"
                        pid == "42" && b.size >= 3 -> String.format(Locale.US, "%.2f V", b.u16(1) / 1000.0)
                        else -> "?"
                    }
                    append("  $name: $v   (raw: ${raw.replace('\n', ' ')})\n")
                }
            }
            append("[7E2] расширенные запросы Toyota (сырые ответы)\n")
            for (c in listOf("1300", "1200", "120000", "1201", "1802FF00", "190209")) {
                append("  $c → ${elm.requestRaw("7E2", c).replace('\n', ' ')}\n")
            }
        }
    }

    /** Polls candidate PIDs whose meaning isn't confirmed for Gen3 (e.g. Delta SOC). Raw output for analysis. */
    private fun probe() = run("Опрос параметров") { elm ->
        buildString {
            val list = listOf("7E2" to "2192", "7E2" to "2193", "7E2" to "2196", "7E2" to "2197", "7E2" to "2199",
                "7E2" to "219A", "7E2" to "2101", "7E2" to "2103", "7E2" to "2181", "7E2" to "2198",
                "7E3" to "2181", "7E3" to "21CE", "7E3" to "21CF", "7E2" to "015B", "7E2" to "0100")
            for ((h, c) in list) append("$h $c → ${elm.requestRaw(h, c).replace('\n', ' ')}\n")
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Сбросить ошибки?")
            .setMessage("Сначала прочитай ошибки и freeze frame и нажми «Сохранить и отправить». После сброса снимок пропадёт.")
            .setPositiveButton("Сбросить") { _, _ ->
                run("Сброс ошибок") { elm -> "7DF 04 → " + elm.requestRaw("7DF", "04", 4000).replace('\n', ' ') }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun saveAndShare() {
        val dir = File(getExternalFilesDir(null), "logs").apply { mkdirs() }
        val f = File(dir, "TOOLS_" + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".txt")
        FileWriter(f).use { it.write(out.text.toString()) }
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "com.ct200h.monitor.files", f)
        val i = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uri).setType("text/plain")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Отправить"))
    }
}
