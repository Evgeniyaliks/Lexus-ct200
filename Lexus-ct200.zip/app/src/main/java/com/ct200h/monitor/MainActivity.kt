package com.ct200h.monitor

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var device: TextView
    private lateinit var big: TextView
    private lateinit var details: TextView
    private lateinit var bars: BlockBarsView
    private lateinit var events: TextView
    private lateinit var startBtn: Button
    private val listener: () -> Unit = { render() }

    private val dp get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt(), (14 * dp).toInt())
        }
        fun tv(size: Float, bold: Boolean = false) = TextView(this).apply {
            textSize = size
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        }
        status = tv(15f, true)
        device = tv(13f).apply { setTextColor(Color.GRAY) }
        big = tv(22f, true)
        details = tv(14f).apply { typeface = Typeface.MONOSPACE }
        bars = BlockBarsView(this)
        events = tv(13f).apply { typeface = Typeface.MONOSPACE }

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startBtn = Button(this).apply { setOnClickListener { toggle() } }
        val pickBtn = Button(this).apply { text = "Адаптер"; setOnClickListener { pickDevice() } }
        row1.addView(startBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(pickBtn, LinearLayout.LayoutParams(0, -2, 1f))

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val logsBtn = Button(this).apply { text = "Логи"; setOnClickListener { shareLogs() } }
        val toolsBtn = Button(this).apply { text = "Ошибки / терминал"; setOnClickListener { startActivity(Intent(this@MainActivity, ToolsActivity::class.java)) } }
        row2.addView(logsBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(toolsBtn, LinearLayout.LayoutParams(0, -2, 1.4f))

        val battBtn = Button(this).apply { text = "Разрешить работу в фоне (батарея)"; setOnClickListener { askBatteryExemption() } }

        root.addView(status); root.addView(device)
        root.addView(row1); root.addView(big); root.addView(bars)
        root.addView(details); root.addView(row2); root.addView(battBtn)
        root.addView(tv(14f, true).apply { text = "События" })
        root.addView(events)
        setContentView(ScrollView(this).apply { addView(root) })

        requestPerms()
    }

    override fun onResume() {
        super.onResume()
        Live.addListener(listener)
        render()
    }

    override fun onPause() {
        Live.removeListener(listener)
        super.onPause()
    }

    private fun prefs() = getSharedPreferences(MonitorService.PREFS, MODE_PRIVATE)

    private fun render() {
        status.text = Live.status
        val name = prefs().getString("name", null)
        device.text = if (name == null) "Адаптер не выбран — нажми «Адаптер»"
            else "Адаптер: $name (${prefs().getString("mode", "auto")})" + (Live.logFile?.let { "\nФайл: $it · ${Live.rows} строк" } ?: "")
        startBtn.text = if (Live.running) "Стоп" else "Старт"
        val s = Live.snap
        if (s == null) {
            big.text = "—"; details.text = ""; bars.blocks = null
        } else {
            big.text = String.format(Locale.US, "SOC %s   разброс %.2f V",
                s.soc?.let { String.format(Locale.US, "%.1f%%", it) } ?: "—", s.spread)
            big.setTextColor(if (s.spread >= 0.5) Color.rgb(230, 60, 60) else Color.rgb(60, 190, 110))
            bars.blocks = s.blocks
            val t = s.tempsF
            details.text = buildString {
                append(String.format(Locale.US, "Ток      %7s A   (+разряд / −заряд)\n", s.current?.let { String.format(Locale.US, "%.1f", it) } ?: "—"))
                append(String.format(Locale.US, "Слабее всех #%d  сильнее всех #%d\n", s.minBlock, s.maxBlock))
                append(String.format(Locale.US, "Отставание слабого  %.2f V от среднего\n", s.avg - s.blocks.min()))
                append("Лимит заряд/разряд  ${s.chargeLimHp?.let { String.format(Locale.US, "%.1f", it) } ?: "—"} / ${s.dischargeLimHp?.let { String.format(Locale.US, "%.1f", it) } ?: "—"} HP\n")
                if (t != null) append(String.format(Locale.US, "Темп. ВВБ  %.0f / %.0f / %.0f °F  (воздух %.0f)\n", t[1], t[2], t[3], t[0]))
                append("12V  ${s.aux?.let { String.format(Locale.US, "%.2f", it) } ?: "—"} V    скорость ${s.speedMph?.let { String.format(Locale.US, "%.0f", it) } ?: "—"} mph\n")
                s.ir?.let { append("IR, mΩ  ${it.joinToString(" ")}\n") }
                s.ecuWeakest?.let { append("Слабейший блок по мнению ЭБУ: #$it\n") }
                append("Ошибки: ${if (Live.dtcs.isEmpty()) "нет" else Live.dtcs.joinToString(", ")}")
            }
        }
        events.text = Live.events.take(20).joinToString("\n")
    }

    private fun toggle() {
        if (Live.running) { MonitorService.stop(this); return }
        if (prefs().getString("addr", null) == null) { pickDevice(); return }
        if (!hasPerms()) { requestPerms(); return }
        MonitorService.start(this)
        render()
    }

    // ---------- permissions ----------

    private fun neededPerms(): Array<String> {
        val l = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN; l += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            l += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }

    private fun hasPerms() = neededPerms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun requestPerms() {
        if (!hasPerms()) requestPermissions(neededPerms(), 1)
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            AlertDialog.Builder(this).setMessage("Уже разрешено: система не будет усыплять запись.").setPositiveButton("OK", null).show()
            return
        }
        try {
            @SuppressLint("BatteryLife")
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            startActivity(i)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    // ---------- device picker ----------

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        if (!hasPerms()) { requestPerms(); return }
        val bm = getSystemService(BluetoothManager::class.java)
        val adapter = bm.adapter
        if (adapter == null || !adapter.isEnabled) {
            AlertDialog.Builder(this).setMessage("Включи Bluetooth").setPositiveButton("OK", null).show(); return
        }
        val found = LinkedHashMap<String, Pair<String, String>>()   // addr -> (label, mode)
        adapter.bondedDevices?.forEach {
            val kind = when (it.type) { BluetoothDevice.DEVICE_TYPE_LE -> "ble"; BluetoothDevice.DEVICE_TYPE_CLASSIC -> "classic"; else -> "auto" }
            found[it.address] = Pair("${it.name ?: "?"}  [сопряжён, $kind]", kind)
        }
        val list = TextView(this).apply { text = "Ищу BLE-устройства 6 секунд…"; setPadding(40, 20, 40, 20) }
        val dlg = AlertDialog.Builder(this).setTitle("Выбор адаптера").setView(list).setNegativeButton("Отмена", null).show()
        val scanner = adapter.bluetoothLeScanner
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device
                if (!found.containsKey(d.address)) {
                    val n = d.name ?: result.scanRecord?.deviceName ?: return
                    found[d.address] = Pair("$n  [BLE, ${result.rssi} dBm]", "ble")
                }
            }
        }
        try { scanner?.startScan(cb) } catch (_: Exception) {}
        Handler(Looper.getMainLooper()).postDelayed({
            try { scanner?.stopScan(cb) } catch (_: Exception) {}
            dlg.dismiss()
            if (isFinishing) return@postDelayed
            val keys = found.keys.toList()
            if (keys.isEmpty()) {
                AlertDialog.Builder(this).setMessage("Ничего не найдено. Проверь, что адаптер в разъёме и зажигание включено.").setPositiveButton("OK", null).show()
                return@postDelayed
            }
            val labels = keys.map { found[it]!!.first + "\n" + it }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Выбери адаптер (Viecar / OBD / V-LINK)")
                .setItems(labels) { _, which ->
                    val addr = keys[which]
                    val p = found[addr]!!
                    prefs().edit().putString("addr", addr).putString("name", p.first.substringBefore("  ")).putString("mode", p.second).apply()
                    render()
                }.show()
        }, 6000)
    }

    // ---------- logs ----------

    private fun shareLogs() {
        val files = CsvLogger(this).listLogs()
        if (files.isEmpty()) {
            AlertDialog.Builder(this).setMessage("Логов пока нет").setPositiveButton("OK", null).show(); return
        }
        val labels = files.map { "${it.name}  (${it.length() / 1024} KB)" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Отправить лог")
            .setItems(labels) { _, which -> share(listOf(files[which])) }
            .setPositiveButton("Отправить последние 5") { _, _ -> share(files.take(5)) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun share(files: List<java.io.File>) {
        val uris = ArrayList(files.map { androidx.core.content.FileProvider.getUriForFile(this, "com.ct200h.monitor.files", it) })
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
                else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "text/csv"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Отправить"))
    }
}
