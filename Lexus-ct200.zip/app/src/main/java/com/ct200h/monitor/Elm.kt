package com.ct200h.monitor

/**
 * ELM327 command layer for Lexus CT200h / Prius Gen3 (ZVW30), CAN 11-bit 500k.
 *
 * Hybrid control ECU: request 7E2, reply 7EA (battery data on Gen3 comes from here).
 * Engine ECU:         request 7E0, reply 7E8.
 * Signal map source: OBDb/Toyota-Prius signalset (Gen3 _G3 signals).
 */
class Elm(private val t: Transport) {
    private var curHeader = ""

    fun raw(cmd: String, timeoutMs: Long = 2000): String {
        t.write(cmd + "\r")
        return t.readUntilPrompt(timeoutMs).replace("\r", "\n").trim()
    }

    fun init(): String {
        val log = StringBuilder()
        log.append(raw("ATZ", 4000)).append('\n')
        Thread.sleep(300)
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATCAF1", "ATSP6", "ATAT1", "ATST64")) {
            log.append(c).append(": ").append(raw(c)).append('\n')
        }
        curHeader = ""
        return log.toString()
    }

    fun header(h: String) {
        if (h != curHeader) {
            raw("ATSH$h")
            curHeader = h
        }
    }

    /** Raw terminal command; forgets the header cache if the user changes AT settings. */
    fun terminal(cmd: String): String {
        val c = cmd.trim().uppercase().replace(" ", "")
        if (c.startsWith("AT")) curHeader = ""
        return raw(c, 4000)
    }

    /** Send a request to [hdr] and return payload bytes after the positive-response prefix, or null. */
    fun request(hdr: String, cmd: String, timeoutMs: Long = 1500): ByteArray? {
        header(hdr)
        val resp = raw(cmd, timeoutMs)
        val prefix = positivePrefix(cmd)
        return Hex.extractAfter(resp, prefix)
    }

    fun requestRaw(hdr: String, cmd: String, timeoutMs: Long = 2000): String {
        header(hdr)
        return raw(cmd, timeoutMs)
    }

    fun batteryVoltage(): Double? {
        val r = raw("ATRV")
        return Regex("([0-9]+\\.[0-9]+)").find(r)?.groupValues?.get(1)?.toDoubleOrNull()
    }

    private fun positivePrefix(cmd: String): String {
        val c = cmd.uppercase()
        val sid = c.substring(0, 2).toInt(16) + 0x40
        // Echo the service + PID for 01/02/21/22; only the service for 03/07/0A
        val echoLen = when (c.substring(0, 2)) {
            "01", "21" -> 4
            "02" -> 4
            "22" -> 6
            else -> 2
        }
        val rest = if (c.length >= echoLen) c.substring(2, echoLen) else ""
        return String.format("%02X", sid) + rest
    }
}

object Hex {
    private val frameLine = Regex("^([0-9A-F]):([0-9A-F]*)$")
    private val lenLine = Regex("^[0-9A-F]{3}$")
    private val hexLine = Regex("^[0-9A-F]+$")

    /** Joins ELM output (single or ISO-TP multi-frame, spaces off, headers off) into one hex string. */
    fun join(resp: String): String {
        val sb = StringBuilder()
        for (raw in resp.split('\n')) {
            val line = raw.trim().replace(" ", "").uppercase()
            if (line.isEmpty()) continue
            val m = frameLine.find(line)
            when {
                m != null -> sb.append(m.groupValues[2])
                lenLine.matches(line) -> {}
                hexLine.matches(line) && line.length % 2 == 0 -> sb.append(line)
            }
        }
        return sb.toString()
    }

    fun extractAfter(resp: String, prefix: String): ByteArray? {
        val hex = join(resp)
        var i = 0
        while (i + prefix.length <= hex.length) {
            if (hex.regionMatches(i, prefix, 0, prefix.length)) {
                return toBytes(hex.substring(i + prefix.length))
            }
            i += 2
        }
        return null
    }

    fun toBytes(hex: String): ByteArray {
        val n = hex.length / 2
        return ByteArray(n) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }
}

fun ByteArray.u8(i: Int): Int = this[i].toInt() and 0xFF
fun ByteArray.u16(i: Int): Int = (u8(i) shl 8) or u8(i + 1)

object Decode {
    const val KW_TO_HP = 1.34102

    /** 21 81 -> 14 block voltages */
    fun blocks(b: ByteArray?): DoubleArray? {
        if (b == null || b.size < 28) return null
        return DoubleArray(14) { b.u16(it * 2) * 79.99 / 65535.0 }
    }

    /** 21 95 -> 14 internal resistances, mOhm */
    fun resistances(b: ByteArray?): IntArray? {
        if (b == null || b.size < 14) return null
        return IntArray(14) { b.u8(it) }
    }

    /** 21 87 -> intake + 3 battery temps, deg F */
    fun temps(b: ByteArray?): DoubleArray? {
        if (b == null || b.size < 8) return null
        return DoubleArray(4) {
            val c = b.u16(it * 2) * 255.9 / 65535.0 - 50.0
            c * 9.0 / 5.0 + 32.0
        }
    }

    /** 21 98 -> current (A, + = discharge), charge limit HP, discharge limit HP */
    fun currentLimits(b: ByteArray?): Triple<Double, Double, Double>? {
        if (b == null || b.size < 4) return null
        val amps = b.u16(0) / 100.0 - 327.68
        val lim1 = Math.abs(b.u8(2) / 2.0 - 64.0) * KW_TO_HP
        val lim2 = Math.abs(b.u8(3) / 2.0 - 64.0) * KW_TO_HP
        return Triple(amps, lim1, lim2)
    }

    /** 21 92 -> ECU's own "weakest block" number */
    fun weakest(b: ByteArray?): Int? {
        if (b == null || b.size < 3) return null
        return b.u8(2)
    }

    /** 01 5B -> SOC % */
    fun soc(b: ByteArray?): Double? {
        if (b == null || b.isEmpty()) return null
        return b.u8(0) * 100.0 / 255.0
    }

    /** 01 0D -> mph */
    fun speedMph(b: ByteArray?): Double? {
        if (b == null || b.isEmpty()) return null
        return b.u8(0) * 0.621371
    }

    /** Mode 03/07/0A payload -> list like ["P0A80"] */
    fun dtcs(b: ByteArray?): List<String> {
        if (b == null || b.isEmpty()) return emptyList()
        var start = 0
        // CAN responses start with a count byte
        val count = b.u8(0)
        if (count * 2 <= b.size - 1 && (b.size - 1) % 2 == 0) start = 1
        val out = mutableListOf<String>()
        var i = start
        while (i + 1 < b.size) {
            val a = b.u8(i); val c = b.u8(i + 1)
            if (a != 0 || c != 0) {
                val letter = "PCBU"[(a shr 6) and 3]
                out.add(String.format("%c%d%X%02X", letter, (a shr 4) and 3, a and 0xF, c))
            }
            i += 2
        }
        return out
    }
}
