package com.ct200h.monitor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Build
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** A byte pipe to the ELM327. readUntilPrompt returns everything up to the '>' prompt. */
interface Transport {
    fun write(s: String)
    fun readUntilPrompt(timeoutMs: Long): String
    fun close()
}

class TransportException(msg: String) : IOException(msg)

private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
private val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

/** Bluetooth Classic (SPP / RFCOMM). */
@SuppressLint("MissingPermission")
class ClassicTransport private constructor(private val socket: BluetoothSocket) : Transport {
    private val input: InputStream = socket.inputStream
    private val output: OutputStream = socket.outputStream

    companion object {
        fun connect(device: BluetoothDevice): ClassicTransport {
            val attempts = listOf<() -> BluetoothSocket>(
                { device.createRfcommSocketToServiceRecord(SPP_UUID) },
                { device.createInsecureRfcommSocketToServiceRecord(SPP_UUID) },
                {
                    val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    m.invoke(device, 1) as BluetoothSocket
                }
            )
            var last: Exception? = null
            for (a in attempts) {
                try {
                    val s = a()
                    s.connect()
                    return ClassicTransport(s)
                } catch (e: Exception) {
                    last = e
                }
            }
            throw TransportException("Classic connect failed: ${last?.message}")
        }
    }

    override fun write(s: String) {
        output.write(s.toByteArray(Charsets.US_ASCII))
        output.flush()
    }

    override fun readUntilPrompt(timeoutMs: Long): String {
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (input.available() > 0) {
                val c = input.read()
                if (c < 0) throw TransportException("stream closed")
                if (c.toChar() == '>') return sb.toString()
                sb.append(c.toChar())
            } else {
                Thread.sleep(5)
            }
        }
        return sb.toString() + "\n<TIMEOUT>"
    }

    override fun close() {
        try { socket.close() } catch (_: Exception) {}
    }
}

/** Bluetooth Low Energy: finds a notify characteristic and a write characteristic. */
@SuppressLint("MissingPermission")
class BleTransport private constructor() : Transport {
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private val buffer = StringBuilder()
    private val lock = Object()
    @Volatile private var writeLatch: CountDownLatch? = null
    @Volatile private var closed = false

    companion object {
        // Preferred service UUID fragments used by common ELM327 BLE clones (Viecar, Vgate, etc.)
        private val PREFERRED = listOf("fff0", "ffe0", "18f0", "e7810a71")

        fun connect(ctx: Context, device: BluetoothDevice): BleTransport {
            val t = BleTransport()
            t.open(ctx, device)
            return t
        }
    }

    private fun open(ctx: Context, device: BluetoothDevice) {
        val ready = CountDownLatch(1)
        var error: String? = null

        val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    g.requestMtu(185)
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    closed = true
                    if (ready.count > 0) { error = "disconnected (status $status)"; ready.countDown() }
                    synchronized(lock) { lock.notifyAll() }
                }
            }

            override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
                g.discoverServices()
            }

            @Suppress("DEPRECATION")
            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                var notifyC: BluetoothGattCharacteristic? = null
                var writeC: BluetoothGattCharacteristic? = null
                val services = g.services.sortedBy { s ->
                    val u = s.uuid.toString().lowercase()
                    val idx = PREFERRED.indexOfFirst { u.contains(it) }
                    if (idx < 0) 99 else idx
                }
                for (s in services) {
                    var n: BluetoothGattCharacteristic? = null
                    var w: BluetoothGattCharacteristic? = null
                    for (c in s.characteristics) {
                        val p = c.properties
                        if (n == null && (p and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0) n = c
                        if (w == null && (p and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) w = c
                    }
                    if (n != null && w != null) { notifyC = n; writeC = w; break }
                }
                if (notifyC == null || writeC == null) {
                    error = "no ELM characteristics found"
                    ready.countDown()
                    return
                }
                writeChar = writeC
                g.setCharacteristicNotification(notifyC, true)
                val d = notifyC.getDescriptor(CCCD_UUID)
                if (d != null) {
                    val v = if ((notifyC.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0)
                        BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    if (Build.VERSION.SDK_INT >= 33) {
                        g.writeDescriptor(d, v)
                    } else {
                        d.value = v
                        g.writeDescriptor(d)
                    }
                } else {
                    ready.countDown()
                }
            }

            override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
                ready.countDown()
            }

            @Deprecated("old API")
            @Suppress("DEPRECATION")
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                if (Build.VERSION.SDK_INT >= 33) return
                onData(c.value ?: return)
            }

            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
                onData(value)
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
                writeLatch?.countDown()
            }
        }

        gatt = device.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        if (!ready.await(15, TimeUnit.SECONDS)) {
            close(); throw TransportException("BLE timeout")
        }
        if (error != null) {
            close(); throw TransportException("BLE: $error")
        }
    }

    private fun onData(bytes: ByteArray) {
        synchronized(lock) {
            buffer.append(String(bytes, Charsets.US_ASCII))
            lock.notifyAll()
        }
    }

    @Suppress("DEPRECATION")
    override fun write(s: String) {
        val g = gatt ?: throw TransportException("not connected")
        val c = writeChar ?: throw TransportException("not connected")
        if (closed) throw TransportException("disconnected")
        val data = s.toByteArray(Charsets.US_ASCII)
        var i = 0
        while (i < data.size) {
            val chunk = data.copyOfRange(i, minOf(i + 20, data.size))
            val type = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            val latch = CountDownLatch(1)
            writeLatch = latch
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, type)
            } else {
                c.writeType = type
                c.value = chunk
                g.writeCharacteristic(c)
            }
            latch.await(500, TimeUnit.MILLISECONDS)
            i += 20
        }
    }

    override fun readUntilPrompt(timeoutMs: Long): String {
        val end = System.currentTimeMillis() + timeoutMs
        synchronized(lock) {
            while (true) {
                val idx = buffer.indexOf(">")
                if (idx >= 0) {
                    val out = buffer.substring(0, idx)
                    buffer.delete(0, idx + 1)
                    return out
                }
                if (closed) throw TransportException("disconnected")
                val left = end - System.currentTimeMillis()
                if (left <= 0) {
                    val out = buffer.toString()
                    buffer.setLength(0)
                    return "$out\n<TIMEOUT>"
                }
                lock.wait(left)
            }
        }
    }

    override fun close() {
        closed = true
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
    }
}
