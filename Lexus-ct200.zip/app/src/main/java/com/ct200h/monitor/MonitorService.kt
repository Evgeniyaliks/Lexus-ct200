package com.ct200h.monitor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import java.util.Locale

/**
 * Foreground service: keeps the adapter connection and logs in the background (screen off, app minimized).
 * Auto mode: waits for the car to answer, starts a new log file on READY, closes it when the car goes quiet.
 */
class MonitorService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val PREFS = "prefs"
        private const val CH_RUN = "run"
        private const val CH_ALERT = "alert"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, MonitorService::class.java).setAction(ACTION_STOP))
        }
    }

    @Volatile private var running = false
    private var worker: Thread? = null
    private var transport: Transport? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var logger: CsvLogger

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        logger = CsvLogger(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Запись", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Ошибки ВВБ", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val n = buildNotification("Запуск…")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (!running) {
            running = true
            Live.running = true
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ct200h:monitor").apply { acquire() }
            worker = Thread({ mainLoop() }, "monitor").apply { start() }
        }
        return START_STICKY
    }

    private fun shutdown() {
        running = false
        Live.running = false
        transport?.close()
        worker?.interrupt()
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        setStatus("Остановлено")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        Live.running = false
        transport?.close()
        logger.stop()
        super.onDestroy()
    }

    // ---------- connection ----------

    @SuppressLint("MissingPermission")
    private fun connect(): Transport {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val addr = prefs.getString("addr", null) ?: throw TransportException("Адаптер не выбран")
        val mode = prefs.getString("mode", "auto") ?: "auto"
        val bm = getSystemService(BluetoothManager::class.java)
        val adapter = bm.adapter ?: throw TransportException("Нет Bluetooth")
        if (!adapter.isEnabled) throw TransportException("Bluetooth выключен")
        val dev: BluetoothDevice = adapter.getRemoteDevice(addr)
        try { adapter.cancelDiscovery() } catch (_: Exception) {}
        return when (mode) {
            "classic" -> ClassicTransport.connect(dev)
            "ble" -> BleTransport.connect(this, dev)
            else -> {
                val bonded = adapter.bondedDevices?.any { it.address == addr } == true
                if (bonded && dev.type != BluetoothDevice.DEVICE_TYPE_LE) {
                    try { ClassicTransport.connect(dev) } catch (e: Exception) { BleTransport.connect(this, dev) }
                } else {
                    BleTransport.connect(this, dev)
                }
            }
        }
    }

    private fun mainLoop() {
        while (running) {
            setStatus("Подключаюсь к адаптеру…")
            val t = try { connect() } catch (e: Exception) {
                setStatus("Адаптер недоступен (${e.message}). Повтор через 10 с")
                sleep(10_000); continue
            }
            transport = t
            try {
                val elm = Elm(t)
                elm.init()
                Live.connected = true
                setStatus("Адаптер подключён. Жду READY…")
                pollLoop(elm)
            } catch (e: Exception) {
                if (running) {
                    setStatus("Связь потеряна: ${e.message}")
                    Live.event("Связь с адаптером потеряна")
                }
            } finally {
                Live.connected = false
                t.close()
                endSession("связь потеряна")
            }
            sleep(3000)
        }
    }

    // ---------- polling ----------

    private var session = false
    private var ir: IntArray? = null
    private var temps: DoubleArray? = null
    private var soc: Double? = null
    private var lastSoc: Double? = null
    private var aux: Double? = null
    private var speed: Double? = null
    private var weakest: Int? = null
    private var current: Double? = null
    private var chg: Double? = null
    private var dis: Double? = null
    private var socHeader = "7E2"
    private val knownDtc = mutableSetOf<String>()
    private var lastCaptureAt = 0L

    private fun pollLoop(elm: Elm) {
        var fails = 0
        var iter = 0
        var lastDtcCheck = 0L
        var lastNotif = 0L
        while (running) {
            runJobs(elm)

            val blocks = Decode.blocks(elm.request("7E2", "2181"))
            if (blocks == null) {
                fails++
                if (session && fails >= 8) endSession("машина не отвечает (зажигание выключено?)")
                if (!session) { setStatus("Адаптер подключён. Жду READY…"); sleep(2000) } else sleep(300)
                continue
            }
            fails = 0
            if (!session) startSession(elm)

            Decode.currentLimits(elm.request("7E2", "2198"))?.let { current = it.first; chg = it.second; dis = it.third }

            if (iter % 4 == 0) {
                Decode.temps(elm.request("7E2", "2187"))?.let { temps = it }
                var s = Decode.soc(elm.request(socHeader, "015B"))
                if (s == null && socHeader == "7E2") { socHeader = "7DF"; s = Decode.soc(elm.request(socHeader, "015B")) }
                if (s != null) soc = s
                Decode.speedMph(elm.request("7E0", "010D"))?.let { speed = it }
                elm.batteryVoltage()?.let { aux = it }
            }
            if (iter % 60 == 0) {
                Decode.resistances(elm.request("7E2", "2195"))?.let { ir = it }
                Decode.weakest(elm.request("7E2", "2192"))?.let { weakest = it }
            }

            val now = System.currentTimeMillis()
            var dtcText = ""
            val events = mutableListOf<String>()
            if (now - lastDtcCheck > 10_000) {
                lastDtcCheck = now
                val found = readDtcs(elm)
                Live.dtcs = found
                dtcText = found.joinToString(" ")
                val fresh = found.filter { it !in knownDtc }
                if (fresh.isNotEmpty()) {
                    knownDtc.addAll(fresh)
                    events.add("DTC " + fresh.joinToString(" "))
                    alert("Ошибка: ${fresh.joinToString(", ")}", "Лог сохранён. Не сбрасывай ошибку, пока не скинешь файлы.")
                    capture("DTC_" + fresh.joinToString("_"), force = true)
                }
            }

            val snap = Snapshot(now, blocks, ir, temps, soc, current, chg, dis, aux, speed, weakest)
            val avg = snap.avg
            val low = avg - blocks.min()
            if (snap.spread >= 0.5) events.add(String.format(Locale.US, "SPREAD %.2fV min#%d max#%d", snap.spread, snap.minBlock, snap.maxBlock))
            if (low >= 0.33) {
                events.add(String.format(Locale.US, "LOW_BLOCK #%d -%.2fV", snap.minBlock, low))
                capture("LOW_BLOCK_${snap.minBlock}")
            }
            val s = soc
            val ls = lastSoc
            if (s != null && ls != null && Math.abs(s - ls) > 3.0) {
                events.add(String.format(Locale.US, "SOC_JUMP %.1f->%.1f", ls, s))
                capture("SOC_JUMP", force = true)
            }
            lastSoc = s

            val ev = events.joinToString(" | ")
            logger.write(snap, ev, dtcText)
            Live.snap = snap
            Live.rows++
            if (events.any { !it.startsWith("SPREAD") }) {
                Live.event("${java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(now)}  $ev")
                logger.appendNote(ev)
            }
            Live.changed()

            if (iter % 20 == 0) logger.flush()
            if (now - lastNotif > 5000) {
                lastNotif = now
                updateNotification(String.format(Locale.US, "Запись · SOC %s · разброс %.2fV · %d строк",
                    soc?.let { String.format(Locale.US, "%.0f%%", it) } ?: "—", snap.spread, Live.rows))
            }
            iter++
        }
    }

    private fun readDtcs(elm: Elm): List<String> {
        val out = LinkedHashSet<String>()
        for (h in listOf("7E2", "7E0")) {
            Decode.dtcs(elm.request(h, "03")).forEach { out.add(it) }
            Decode.dtcs(elm.request(h, "07")).forEach { out.add("$it(ож.)") }
        }
        return out.toList()
    }

    private fun capture(label: String, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastCaptureAt < 60_000) return
        lastCaptureAt = now
        logger.captureEvent(label)?.let { Live.event("Сохранён отрезок: ${it.name}") }
    }

    private fun startSession(elm: Elm) {
        val f = logger.startSession()
        session = true
        Live.logFile = f.name
        Live.rows = 0
        lastSoc = null
        // Errors already stored when the car started are recorded but don't trigger alerts
        knownDtc.clear()
        val existing = readDtcs(elm)
        knownDtc.addAll(existing)
        Live.dtcs = existing
        if (existing.isNotEmpty()) {
            Live.event("При старте уже есть ошибки: ${existing.joinToString(", ")}")
            logger.appendNote("Ошибки при старте: ${existing.joinToString(", ")}")
        }
        Live.event("Старт записи: ${f.name}")
        setStatus("Запись идёт")
    }

    private fun endSession(reason: String) {
        if (!session) return
        session = false
        logger.stop()
        Live.event("Запись остановлена: $reason")
        Live.logFile = null
        setStatus("Жду READY…")
    }

    private fun runJobs(elm: Elm) {
        while (true) {
            val j = Live.jobs.poll() ?: break
            val r = try { j.work(elm) } catch (e: Exception) { "Ошибка: ${e.message}" }
            j.done(r)
        }
    }

    // ---------- helpers ----------

    private fun setStatus(s: String) {
        Live.status = s
        Live.changed()
        updateNotification(s)
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("CT200h Монитор")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!running) return
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {}
    }

    private fun alert(title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
            val v = getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1))
        } catch (_: Exception) {}
    }
}
